using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace FutebolDeDiscos
{
    internal sealed class HudShortsDiscos
    {
        public const float Largura = 1080f;
        public const float Altura = 1920f;
        private static readonly Color Fundo = new Color(.018f, .043f, .064f, .97f);
        private static readonly Color Placa = new Color(.036f, .085f, .107f, .98f);
        private static readonly Color Linha = new Color(.20f, .35f, .36f, .84f);
        private static readonly Color Claro = new Color(.66f, .89f, .83f);
        private static readonly Color Menta = new Color(.34f, 1f, .76f);
        private readonly TMP_FontAsset fonteTitulo, fonteTexto;
        private readonly TeamData timeA, timeB;
        private readonly Color corEspecial;
        private readonly TextMeshProUGUI chamada;
        private readonly RectTransform resultado;
        private readonly TextMeshProUGUI placarFinal, vencedor;
        private readonly Image cargaA, cargaB;
        private bool exibiuInicio;

        public HudShortsDiscos(Transform pai, TemaCompeticao tema, TeamData equipeA, TeamData equipeB,
            Color corA, Color corB, bool comCapitaes, Color especial, UniversalUI ui, GoalBannerUI banner)
        {
            timeA = equipeA;
            timeB = equipeB;
            corEspecial = especial;
            TMP_FontAsset padrao = TMP_Settings.defaultFontAsset;
            if (padrao == null) padrao = Resources.Load<TMP_FontAsset>("Fonts & Materials/LiberationSans SDF");
            fonteTexto = tema != null && tema.fonteTexto != null ? tema.fonteTexto : padrao;
            fonteTitulo = tema != null && tema.fonteTitulo != null ? tema.fonteTitulo : fonteTexto;
            if (fonteTitulo == null || fonteTexto == null)
                throw new InvalidOperationException("Atribua uma fonte TMP ao tema de Shorts.");

            var objetoCanvas = new GameObject("Shorts Overlay", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler));
            objetoCanvas.transform.SetParent(pai, false);
            Canvas canvas = objetoCanvas.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 100;
            CanvasScaler scaler = objetoCanvas.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(Largura, Altura);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;
            RectTransform raiz = Retangulo((RectTransform)objetoCanvas.transform, "Portrait Frame", Largura, Altura);
            raiz.anchorMin = raiz.anchorMax = raiz.pivot = new Vector2(.5f, .5f);
            raiz.anchoredPosition = Vector2.zero;

            RectTransform topo = Caixa(raiz, "Scoreboard", 64f, 96f, 866f, 158f, Fundo);
            Caixa(topo, "Top Line", 0f, 0f, 866f, 3f, Menta);
            chamada = Texto(topo, "Match status", "WHO WINS?", 22f, 8f, 580f, 43f, 29f, Claro,
                TextAlignmentOptions.Left);
            ui.textoCronometro = Texto(topo, "Match clock", "00:00", 632f, 6f, 212f, 47f, 39f, Color.white,
                TextAlignmentOptions.Right);
            Caixa(topo, "Divider", 18f, 54f, 830f, 2f, Linha);

            RectTransform ladoA = Caixa(topo, "Home Team", 14f, 62f, 411f, 80f, Placa);
            RectTransform ladoB = Caixa(topo, "Away Team", 441f, 62f, 411f, 80f, Placa);
            Caixa(ladoA, "Home team color", 0f, 0f, 5f, 80f, corA);
            Caixa(ladoB, "Away team color", 406f, 0f, 5f, 80f, corB);
            ui.escudoTimeA = Imagem(ladoA, "Home crest", 14f, 12f, 56f, 56f, timeA.escudoOuBandeira);
            ui.escudoTimeB = Imagem(ladoB, "Away crest", 341f, 12f, 56f, 56f, timeB.escudoOuBandeira);
            Texto(ladoA, "Home name", Nome(timeA), 82f, 10f, 229f, 58f, 34f, Color.white, TextAlignmentOptions.Left);
            Texto(ladoB, "Away name", Nome(timeB), 100f, 10f, 229f, 58f, 34f, Color.white, TextAlignmentOptions.Right);
            ui.placarTimeA = Texto(ladoA, "Home score", "0", 316f, 4f, 90f, 70f, 61f, Color.white, TextAlignmentOptions.Center);
            ui.placarTimeB = Texto(ladoB, "Away score", "0", 5f, 4f, 90f, 70f, 61f, Color.white, TextAlignmentOptions.Center);

            if (comCapitaes)
            {
                cargaA = CriarBarra(topo, "Home Captain Power", 14f);
                cargaB = CriarBarra(topo, "Away Captain Power", 441f);
            }

            // The original goal queue animates this portrait-safe overlay and its scorer image.
            RectTransform gol = Caixa(raiz, "Goal Celebration", 159f, 420f, 662f, 126f, Fundo);
            Caixa(gol, "Goal accent", 0f, 0f, 5f, 126f, Menta);
            banner.painelBanner = gol.gameObject;
            banner.fotoJogador = Imagem(gol, "Scorer photo", 20f, 17f, 92f, 92f, null);
            banner.textoDados = Texto(gol, "Scorer", "GOAL!", 124f, 5f, 517f, 116f, 43f, Color.white,
                TextAlignmentOptions.Center);
            banner.textoDados.textWrappingMode = TextWrappingModes.Normal;
            banner.textoDados.richText = true;
            ui.bannerGol = gol.gameObject;
            gol.gameObject.SetActive(false);

            resultado = Caixa(raiz, "Full Time", 138f, 845f, 704f, 227f, Fundo);
            Caixa(resultado, "Result accent", 0f, 0f, 704f, 4f, Menta);
            Texto(resultado, "Full time label", "FULL TIME", 26f, 19f, 652f, 41f, 31f, Claro, TextAlignmentOptions.Center);
            placarFinal = Texto(resultado, "Final score", "", 26f, 60f, 652f, 90f, 80f, Color.white, TextAlignmentOptions.Center);
            vencedor = Texto(resultado, "Match outcome", "", 26f, 153f, 652f, 54f, 38f, Menta, TextAlignmentOptions.Center);
            resultado.gameObject.SetActive(false);
        }

        public void Atualizar(PartidaDiscos partida, float tempo)
        {
            if (!exibiuInicio && tempo >= 2f)
            {
                chamada.text = "LIVE";
                exibiuInicio = true;
            }
            if (cargaA == null || cargaB == null) return;
            AtualizarBarra(cargaA, partida, true);
            AtualizarBarra(cargaB, partida, false);
        }

        public void MostrarResultado(int golsA, int golsB)
        {
            chamada.text = "FULL TIME";
            placarFinal.text = golsA + "  –  " + golsB;
            vencedor.text = golsA == golsB ? "DRAW" : Nome(golsA > golsB ? timeA : timeB) + " WINS";
            resultado.gameObject.SetActive(true);
        }

        private void AtualizarBarra(Image barra, PartidaDiscos partida, bool timeDaCasa)
        {
            float carga = partida.CargaCapitao(timeDaCasa) / (float)PartidaDiscos.ToquesParaEspecial;
            barra.rectTransform.sizeDelta = new Vector2(411f * carga, 7f);
            barra.color = corEspecial;
            if (partida.RoletaAtiva(timeDaCasa))
                barra.color = Color.Lerp(corEspecial, Color.white, Mathf.PingPong(partida.ProgressoRoleta * 8f, 1f));
            else if (partida.EspecialArmado(timeDaCasa))
                barra.color = partida.AcertoArmado(timeDaCasa) ? Menta : new Color(.95f, .32f, .27f);
        }

        private Image CriarBarra(RectTransform topo, string nome, float x)
        {
            Caixa(topo, nome + " track", x, 146f, 411f, 7f, Linha);
            Image barra = Caixa(topo, nome, x, 146f, 0f, 7f, corEspecial).GetComponent<Image>();
            return barra;
        }

        private static string Nome(TeamData time)
        {
            string nome = string.IsNullOrWhiteSpace(time.nomeEquipe) ? time.name : time.nomeEquipe;
            return nome.Trim().ToUpperInvariant();
        }

        private static RectTransform Retangulo(RectTransform pai, string nome, float largura, float altura)
        {
            var objeto = new GameObject(nome, typeof(RectTransform));
            var rect = (RectTransform)objeto.transform;
            rect.SetParent(pai, false);
            rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(0f, 1f);
            rect.sizeDelta = new Vector2(largura, altura);
            return rect;
        }

        private static RectTransform Posicionar(RectTransform pai, string nome, float x, float y, float w, float h)
        {
            RectTransform rect = Retangulo(pai, nome, w, h);
            rect.anchoredPosition = new Vector2(x, -y);
            return rect;
        }

        private static RectTransform Caixa(RectTransform pai, string nome, float x, float y, float w, float h, Color cor)
        {
            RectTransform rect = Posicionar(pai, nome, x, y, w, h);
            Image imagem = rect.gameObject.AddComponent<Image>();
            imagem.color = cor;
            imagem.raycastTarget = false;
            return rect;
        }

        private static Image Imagem(RectTransform pai, string nome, float x, float y, float w, float h, Sprite sprite)
        {
            Image imagem = Posicionar(pai, nome, x, y, w, h).gameObject.AddComponent<Image>();
            imagem.sprite = sprite;
            imagem.preserveAspect = true;
            imagem.raycastTarget = false;
            imagem.enabled = sprite != null;
            return imagem;
        }

        private TextMeshProUGUI Texto(RectTransform pai, string nome, string valor, float x, float y, float w, float h,
            float tamanho, Color cor, TextAlignmentOptions alinhamento)
        {
            var texto = Posicionar(pai, nome, x, y, w, h).gameObject.AddComponent<TextMeshProUGUI>();
            texto.font = tamanho >= 61f ? fonteTitulo : fonteTexto;
            texto.fontStyle = FontStyles.Bold;
            texto.fontSize = tamanho;
            texto.enableAutoSizing = true;
            texto.fontSizeMin = tamanho * .62f;
            texto.fontSizeMax = tamanho;
            texto.alignment = alinhamento;
            texto.textWrappingMode = TextWrappingModes.NoWrap;
            texto.overflowMode = TextOverflowModes.Ellipsis;
            texto.richText = false;
            texto.color = cor;
            texto.text = valor;
            texto.raycastTarget = false;
            return texto;
        }
    }
}
