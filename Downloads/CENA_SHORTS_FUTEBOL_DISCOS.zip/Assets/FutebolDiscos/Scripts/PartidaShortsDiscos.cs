using System;
using UnityEngine;

namespace FutebolDeDiscos
{
    [DisallowMultipleComponent]
    [AddComponentMenu("Futebol de Discos/Partida para Shorts")]
    public sealed class PartidaShortsDiscos : MonoBehaviour
    {
        [Header("Confronto")]
        [SerializeField] private TeamData timeA, timeB;
        [Tooltip("Opcionais. Preencha os dois para jogar com os especiais de capitão.")]
        [SerializeField] private CapitaoConvidado capitaoA, capitaoB;
        [Tooltip("Tempo de bola em jogo, em segundos. As pausas de gol são somadas a esse tempo.")]
        [SerializeField, Range(10f, 90f)] private float duracao = 30f;
        [SerializeField] private int semente;
        [SerializeField, Range(2, 5)] private int discosPorTime = 3;

        [Header("Visual vertical")]
        [SerializeField] private TemaCompeticao tema;
        [SerializeField] private Sprite imagemNoCampo, imagemForaDoCampo;
        [SerializeField, Range(0f, 1f)] private float opacidadeImagemNoCampo = .35f, opacidadeImagemForaDoCampo = .65f;
        [SerializeField] private Color corCampo = new Color(.025f, .21f, .17f);
        [SerializeField] private Color corLinhas = new Color(.75f, 1f, .89f);
        [SerializeField] private Color corEspecial = new Color(.99f, .78f, .30f);
        [SerializeField] private bool mostrarNomesDosJogadores = true;

        [Header("Áudio")]
        [SerializeField] private AudioClip musicaPartida;
        [SerializeField, Range(0f, 1f)] private float volumeMusica = .35f, volumeEfeitos = .7f;

        [SerializeField, HideInInspector] private Camera cameraVertical;
        [SerializeField, HideInInspector] private ProjetoFutebolDiscos regras;
        [SerializeField, HideInInspector] private UniversalUI interfacePartida;
        [SerializeField, HideInInspector] private GoalBannerUI banner;
        [SerializeField, HideInInspector] private PartidaDiscos partida;

        private const float AlturaCamera = 16.1f;
        private static readonly Quaternion RotacaoVertical = Quaternion.Euler(0f, 0f, -90f);
        private HudShortsDiscos hud;
        private int larguraVista, alturaVista;
        private bool iniciou, mostrouResultado;

        private void Start()
        {
            try
            {
                ValidarConfronto();
                AjustarCamera();
                PrepararConfiguracao();

                var objetoCampo = new GameObject("Shorts Stadium");
                objetoCampo.transform.SetParent(transform, false);
                var campo = objetoCampo.AddComponent<CampoDiscos>();
                campo.Construir(regras);

                TeamData.EscolherCoresParaPartida(timeA, timeB, regras.limiarCores, out Color corA, out Color corB);
                partida.Configurar(regras, campo, null);
                var representantesA = regras.SelecionarRepresentantes(timeA);
                var representantesB = regras.SelecionarRepresentantes(timeB);
                partida.PrepararPartida(timeA, timeB, representantesA, representantesB, corA, corB);
                OrientarJogadores();
                // Reset the existing match clock and score before mounting the canvas,
                // so UniversalUI does not add the landscape player cards.
                interfacePartida.ConfigurarPartida(timeA, timeB, null, representantesA, representantesB);
                hud = new HudShortsDiscos(transform, tema, timeA, timeB, corA, corB,
                    regras.usarCapitaesConvidados, corEspecial, interfacePartida, banner);
                partida.IniciarPartida(timeA, timeB, duracao, representantesA, representantesB, corA, corB);
                iniciou = true;
                interfacePartida.IniciarCronometro();
            }
            catch (Exception erro)
            {
                Debug.LogError("Shorts: " + erro.Message, this);
                enabled = false;
            }
        }

        private void ValidarConfronto()
        {
            if (cameraVertical == null || regras == null || interfacePartida == null || banner == null || partida == null)
                throw new InvalidOperationException("Faltam componentes da cena Shorts. Reimporte a cena do pacote.");
            if (timeA == null || timeB == null || timeA == timeB)
                throw new InvalidOperationException("Escolha duas fichas de times diferentes no Inspector de Shorts.");
            if ((capitaoA == null) != (capitaoB == null) || (capitaoA != null && capitaoA == capitaoB))
                throw new InvalidOperationException("Escolha dois capitães diferentes ou deixe os dois campos vazios.");
            if (capitaoA != null && (string.IsNullOrWhiteSpace(capitaoA.nomeCapitao) || string.IsNullOrWhiteSpace(capitaoB.nomeCapitao)))
                throw new InvalidOperationException("Preencha o nome nas duas fichas de capitães.");
        }

        private void PrepararConfiguracao()
        {
            regras.tema = tema;
            regras.discosPorTime = Mathf.Clamp(discosPorTime, 2, 5);
            regras.semente = semente;
            regras.capitaoExtra = false;
            regras.tamanhoDisco = 1.12f;
            regras.tamanhoBola = .47f;
            regras.pausaAposGol = .85f;
            regras.mostrarTextoNoCampo = false;
            regras.mostrarTagsJogadores = mostrarNomesDosJogadores;
            regras.larguraTags = 2.6f;
            regras.fundoCampo = imagemNoCampo;
            regras.fundoExternoArena = imagemForaDoCampo;
            regras.opacidadeImagemCampo = opacidadeImagemNoCampo;
            regras.opacidadeFundoExterno = opacidadeImagemForaDoCampo;
            regras.corGramado = corCampo;
            regras.corLinhas = corLinhas;
            regras.corContornoCampo = corLinhas;
            regras.corBarraCapitao = corEspecial;
            regras.ConfigurarCapitaesDaPartidaAvulsa(timeA, capitaoA, timeB, capitaoB);

            duracao = Mathf.Clamp(duracao, 10f, 90f);
            interfacePartida.duracaoRealEmSegundos = duracao;
            interfacePartida.ativarGoldenGoal = false;
            interfacePartida.tempoCongeladoPosJogo = .2f;
            interfacePartida.mostrarPlacarFinal = false;
            interfacePartida.musicaPartida = musicaPartida;
            interfacePartida.volumeMusica = volumeMusica;
            interfacePartida.volumeSons = volumeEfeitos;
            if (tema != null)
            {
                if (tema.somGolDiscos != null) interfacePartida.somGol = tema.somGolDiscos;
                if (tema.somApitoInicialDiscos != null) interfacePartida.somApitoInicial = tema.somApitoInicialDiscos;
                if (tema.somApitoFinalDiscos != null) interfacePartida.somApitoFinal = tema.somApitoFinalDiscos;
                if (tema.somToqueBolaDiscos != null) interfacePartida.somToqueBola = tema.somToqueBolaDiscos;
            }
            banner.tempoDeExibicao = 1.15f;
            banner.intervaloEntreBanners = .08f;
            banner.ConfigurarCorEspecial(corEspecial);
        }

        private void AjustarCamera()
        {
            larguraVista = Mathf.Max(1, Screen.width);
            alturaVista = Mathf.Max(1, Screen.height);
            float aspecto = HudShortsDiscos.Largura / HudShortsDiscos.Altura;
            float proporcaoVista = (float)larguraVista / alturaVista;
            float w = Mathf.Min(1f, aspecto / proporcaoVista);
            float h = Mathf.Min(1f, proporcaoVista / aspecto);
            cameraVertical.rect = new Rect((1f - w) * .5f, (1f - h) * .5f, w, h);
            cameraVertical.aspect = aspecto;
            cameraVertical.orthographicSize = AlturaCamera;

            // Reserve room above the goals for the scoreboard and at the right for Shorts controls.
            float unidadesPorPixel = AlturaCamera * 2f / HudShortsDiscos.Altura;
            Vector3 desvio = RotacaoVertical * new Vector3(50f * unidadesPorPixel, 48f * unidadesPorPixel, 0f);
            cameraVertical.transform.SetPositionAndRotation(desvio + Vector3.back * 10f, RotacaoVertical);
        }

        private void OrientarJogadores()
        {
            foreach (DiscoAtleta atleta in partida.Atletas)
            {
                // All direct children of a disc are visual. Rotate the placement as well
                // so the caption is below the disc and the captain badge stays above it.
                foreach (Transform elemento in atleta.transform)
                {
                    elemento.localPosition = RotacaoVertical * elemento.localPosition;
                    elemento.localRotation = RotacaoVertical * elemento.localRotation;
                }
            }
        }

        private void Update()
        {
            if (!iniciou) return;
            if (larguraVista != Screen.width || alturaVista != Screen.height) AjustarCamera();
            if (mostrouResultado) return;
            hud.Atualizar(partida, interfacePartida.TempoAtual);
            // UniversalUI freezes gameplay while it drains the goal banner queue.
            if (!interfacePartida.partidaEmAndamento && Time.timeScale > 0f && !banner.TemBannersPendentes)
            {
                mostrouResultado = true;
                hud.MostrarResultado(interfacePartida.GolsA, interfacePartida.GolsB);
            }
        }

        private void OnDisable()
        {
            if (iniciou && interfacePartida != null) interfacePartida.CancelarPartida();
            iniciou = false;
        }
    }
}
