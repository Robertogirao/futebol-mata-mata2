#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public sealed class GeradorPokemonWindow : EditorWindow
{
    // Campos antigos são mantidos apenas para migrar preferências da janela.
    private enum Modo { TodosOsTipos, UmTipo, Manual, MisturarTipos }
    private static readonly string[] NomesGeracoes = {
        "Todas juntas", "I — Kanto", "II — Johto", "III — Hoenn", "IV — Sinnoh",
        "V — Unova", "VI — Kalos", "VII — Alola", "VIII — Galar / Hisui", "IX — Paldea"
    };
    private const string CaminhoBiblioteca = "Assets/Pokemon/FundosIlustrados/Biblioteca_Fundos.asset";
    private const string PastaLotes = "Assets/Pokemon/Gerados";
    private const string ArquivoChaveamentos = "chaveamentos.txt";
    [SerializeField] private SceneAsset cenaBase;
    [SerializeField] private TemaCompeticao temaBase;
    [SerializeField] private BibliotecaFundosPokemon biblioteca;
    [SerializeField] private Modo modo = Modo.TodosOsTipos;
    [SerializeField] private TipoPokemon tipo = TipoPokemon.Fogo;
    [SerializeField] private int geracao;
    [SerializeField] private bool filtrosMultiplosInicializados;
    [SerializeField] private List<TipoPokemon> tiposSelecionados = new List<TipoPokemon>();
    [SerializeField] private List<int> geracoesSelecionadas = new List<int>();
    [SerializeField] private bool selecaoManual;
    [SerializeField] private int quantidadeCenas = 1;
    [SerializeField] private int tamanho;
    [SerializeField] private int semente = 2026;
    [SerializeField] private bool salvarProgresso = true;
    [SerializeField] private bool somenteUmaFase;
    [SerializeField] private List<PokemonDados> manuais = new List<PokemonDados>();
    private List<PokemonDados> catalogo = new List<PokemonDados>();
    private string filtrosDaPrevia;
    private int elegiveisNaPrevia;
    private Vector2 rolagem;
    private string mensagem;
    [SerializeField] private string primeiraCena;
    [SerializeField] private string pastaGerada;

    [MenuItem("Tools/Pokémon/Gerador de torneios")]
    public static void Abrir()
    {
        var janela = GetWindow<GeradorPokemonWindow>("Gerador Pokémon");
        janela.minSize = new Vector2(540, 680);
        janela.Show();
    }

    private void OnEnable()
    {
        MigrarPreferencias();
        string caminho = SceneManager.GetActiveScene().path;
        if (cenaBase == null && !string.IsNullOrEmpty(caminho))
            cenaBase = AssetDatabase.LoadAssetAtPath<SceneAsset>(caminho);
        if (cenaBase == null)
            cenaBase = AssetDatabase.LoadAssetAtPath<SceneAsset>("Assets/Pokemon/Cenas/Teste_Pokemon_16.unity");
        TorneioPokemon atual = UnityEngine.Object.FindFirstObjectByType<TorneioPokemon>();
        if (temaBase == null && atual != null) temaBase = atual.tema;
        if (temaBase == null)
            temaBase = AssetDatabase.LoadAssetAtPath<TemaCompeticao>("Assets/Pokemon/Temas/Tema_Pokemon_Laboratorio.asset");
        if (biblioteca == null) biblioteca = ProcurarBibliotecaInstalada();
        CarregarCatalogo();
    }

    private void MigrarPreferencias()
    {
        if (tiposSelecionados == null) tiposSelecionados = new List<TipoPokemon>();
        if (geracoesSelecionadas == null) geracoesSelecionadas = new List<int>();
        if (manuais == null) manuais = new List<PokemonDados>();
        if (filtrosMultiplosInicializados) return;
        selecaoManual = modo == Modo.Manual;
        tiposSelecionados.Clear();
        if ((modo == Modo.UmTipo || modo == Modo.Manual) && (int)tipo >= 1 && (int)tipo <= 18)
            tiposSelecionados.Add(tipo);
        else SelecionarTodosTipos();
        geracoesSelecionadas.Clear();
        if (geracao >= 1 && geracao <= 9) geracoesSelecionadas.Add(geracao);
        else SelecionarTodasGeracoes();
        quantidadeCenas = 1;
        filtrosMultiplosInicializados = true;
    }

    private void SelecionarTodosTipos()
    {
        tiposSelecionados.Clear();
        for (int i = 1; i <= 18; i++) tiposSelecionados.Add((TipoPokemon)i);
    }

    private void SelecionarTodasGeracoes()
    {
        geracoesSelecionadas.Clear();
        for (int i = 1; i <= 9; i++) geracoesSelecionadas.Add(i);
    }

    private void CarregarCatalogo()
    {
        filtrosDaPrevia = null;
        try
        {
            var fichas = new List<PokemonDados>();
            foreach (string guid in AssetDatabase.FindAssets("t:PokemonDados"))
            {
                PokemonDados ficha = AssetDatabase.LoadAssetAtPath<PokemonDados>(AssetDatabase.GUIDToAssetPath(guid));
                if (ficha != null) fichas.Add(ficha);
            }
            catalogo = GeradorTorneiosPokemon.ConferirCatalogo(fichas);
            mensagem = catalogo.Count + " fichas válidas carregadas.";
        }
        catch (Exception erro) { catalogo.Clear(); mensagem = erro.Message; }
    }

    private void OnGUI()
    {
        MigrarPreferencias();
        rolagem = EditorGUILayout.BeginScrollView(rolagem);
        GUILayout.Label("Torneios com filtros múltiplos", EditorStyles.boldLabel);
        EditorGUILayout.HelpBox("Marque as gerações e os tipos permitidos. Os Pokémon dessas opções formam um único conjunto para o sorteio. Escolha quantas cenas criar; o padrão é uma cena.", MessageType.Info);
        using (new EditorGUI.DisabledScope(EditorApplication.isPlayingOrWillChangePlaymode))
        {
            cenaBase = (SceneAsset)EditorGUILayout.ObjectField("Cena base salva", cenaBase, typeof(SceneAsset), false);
            temaBase = (TemaCompeticao)EditorGUILayout.ObjectField("Tema base", temaBase, typeof(TemaCompeticao), false);
            biblioteca = (BibliotecaFundosPokemon)EditorGUILayout.ObjectField("Fundos ilustrados", biblioteca, typeof(BibliotecaFundosPokemon), false);
            EditorGUILayout.HelpBox("Salve os ajustes da cena base antes de gerar. Ela fornece a arena, a hélice, o goleiro, os tempos e a interface.", MessageType.Info);
            tamanho = EditorGUILayout.Popup("Participantes por cena", tamanho, new[] { "16 — oitavas", "32 — dezesseis avos" });
            quantidadeCenas = Math.Max(1, EditorGUILayout.IntField("Quantidade de cenas", quantidadeCenas));
            selecaoManual = EditorGUILayout.Popup("Participantes", selecaoManual ? 1 : 0,
                new[] { "Sortear pelo catálogo", "Escolher manualmente" }) == 1;
            DesenharFiltros();
            int vagas = tamanho == 0 ? 16 : 32;
            ExibirPrevia(vagas);
            if (selecaoManual)
            {
                while (manuais.Count < vagas) manuais.Add(null);
                if (GUILayout.Button("Usar os mesmos Pokémon da cena aberta")) CopiarParticipantesDaCena();
                EditorGUILayout.HelpBox("Cada cena mantém estes mesmos " + vagas + " Pokémon e sorteia novos confrontos. A lista abaixo não é alterada.", MessageType.Info);
                for (int i = 0; i < vagas; i++)
                    manuais[i] = (PokemonDados)EditorGUILayout.ObjectField("Vaga " + (i + 1), manuais[i], typeof(PokemonDados), false);
            }
            EditorGUILayout.HelpBox("Cada clique gera um novo sorteio. Confrontos já registrados nos lotes desta pasta não são repetidos. Um Pokémon pode aparecer em cenas diferentes, mas não se repete dentro da mesma cena.", MessageType.Info);
            salvarProgresso = EditorGUILayout.Toggle("Salvar progresso", salvarProgresso);
            somenteUmaFase = EditorGUILayout.Toggle("Uma fase por Play", somenteUmaFase);
            if (GUILayout.Button("Atualizar catálogo")) CarregarCatalogo();
            if (GUILayout.Button("Gerar " + quantidadeCenas + " cena(s) — novo lote")) Gerar();
            if (GUILayout.Button("Atualizar fundos e títulos dos lotes existentes")) AtualizarLotesExistentes();
        }
        if (!string.IsNullOrEmpty(mensagem)) EditorGUILayout.HelpBox(mensagem, MessageType.Info);
        if (!string.IsNullOrEmpty(primeiraCena))
        {
            if (GUILayout.Button("Abrir primeiro torneio gerado") &&
                !EditorApplication.isPlayingOrWillChangePlaymode &&
                EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            {
                EditorSceneManager.OpenScene(primeiraCena);
                Selection.activeGameObject = GameObject.Find("Torneio_Pokemon");
            }
            if (GUILayout.Button("Abrir pasta do lote")) EditorUtility.RevealInFinder(pastaGerada);
        }
        EditorGUILayout.EndScrollView();
    }

    private void DesenharFiltros()
    {
        EditorGUILayout.Space();
        GUILayout.Label("Gerações permitidas", EditorStyles.boldLabel);
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("Todas as gerações")) SelecionarTodasGeracoes();
        if (GUILayout.Button("Limpar gerações")) geracoesSelecionadas.Clear();
        EditorGUILayout.EndHorizontal();
        for (int inicio = 1; inicio <= 9; inicio += 3)
        {
            EditorGUILayout.BeginHorizontal();
            for (int i = inicio; i < inicio + 3 && i <= 9; i++)
            {
                bool atual = geracoesSelecionadas.Contains(i);
                bool marcado = EditorGUILayout.ToggleLeft(NomesGeracoes[i], atual);
                if (marcado && !atual) geracoesSelecionadas.Add(i);
                else if (!marcado && atual) geracoesSelecionadas.Remove(i);
            }
            EditorGUILayout.EndHorizontal();
        }
        EditorGUILayout.Space();
        GUILayout.Label("Tipos permitidos", EditorStyles.boldLabel);
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("Todos os tipos")) SelecionarTodosTipos();
        if (GUILayout.Button("Limpar tipos")) tiposSelecionados.Clear();
        EditorGUILayout.EndHorizontal();
        for (int inicio = 1; inicio <= 18; inicio += 3)
        {
            EditorGUILayout.BeginHorizontal();
            for (int i = inicio; i < inicio + 3 && i <= 18; i++)
            {
                TipoPokemon candidato = (TipoPokemon)i;
                bool atual = tiposSelecionados.Contains(candidato);
                bool marcado = EditorGUILayout.ToggleLeft(candidato.ToString(), atual);
                if (marcado && !atual) tiposSelecionados.Add(candidato);
                else if (!marcado && atual) tiposSelecionados.Remove(candidato);
            }
            EditorGUILayout.EndHorizontal();
        }
    }

    private void ExibirPrevia(int vagas)
    {
        try
        {
            var tipos = FiltrosPokemon.NormalizarTipos(tiposSelecionados);
            var geracoes = FiltrosPokemon.NormalizarGeracoes(geracoesSelecionadas);
            string chave = string.Join(",", tipos.ConvertAll(t => ((int)t).ToString()).ToArray()) +
                ":" + string.Join(",", geracoes.ConvertAll(g => g.ToString()).ToArray());
            if (filtrosDaPrevia != chave)
            {
                elegiveisNaPrevia = GeradorTorneiosPokemon.ContarElegiveis(catalogo, tipos, geracoes);
                filtrosDaPrevia = chave;
            }
            int total = elegiveisNaPrevia;
            EditorGUILayout.LabelField("Pokémon elegíveis no catálogo", total.ToString());
            EditorGUILayout.LabelField("Cenas a gerar", quantidadeCenas.ToString());
            EditorGUILayout.HelpBox("Participa quem pertence a uma das gerações marcadas E tem pelo menos um dos tipos marcados, como tipo primário ou secundário.", MessageType.Info);
            if (total < vagas && !selecaoManual)
                EditorGUILayout.HelpBox("Faltam " + (vagas - total) + " Pokémon para completar uma cena de " + vagas + ". Selecione mais gerações ou tipos.", MessageType.Warning);
        }
        catch (ArgumentException erro) { EditorGUILayout.HelpBox(erro.Message, MessageType.Warning); }
    }

    private void CopiarParticipantesDaCena()
    {
        TorneioPokemon torneio = UnityEngine.Object.FindFirstObjectByType<TorneioPokemon>();
        int vagas = tamanho == 0 ? 16 : 32;
        if (torneio == null || torneio.participantes == null || torneio.participantes.Count < vagas)
        {
            mensagem = "Abra uma cena com pelo menos " + vagas + " participantes e selecione o tamanho correto.";
            return;
        }
        try
        {
            if (torneio.tema != null)
            {
                torneio.tema.ConferirFiltrosPokemon();
                if (torneio.tema.usarFiltrosMultiplosPokemon)
                {
                    tiposSelecionados = FiltrosPokemon.NormalizarTipos(torneio.tema.tiposPokemonPermitidos);
                    geracoesSelecionadas = FiltrosPokemon.NormalizarGeracoes(torneio.tema.geracoesPokemonPermitidas);
                }
                else
                {
                    if (torneio.tema.filtrarPorTipoPokemon)
                        tiposSelecionados = new List<TipoPokemon> { torneio.tema.tipoPokemonPermitido };
                    else SelecionarTodosTipos();
                    if (torneio.tema.geracaoPokemonPermitida > 0)
                        geracoesSelecionadas = new List<int> { torneio.tema.geracaoPokemonPermitida };
                    else SelecionarTodasGeracoes();
                }
            }
            manuais = torneio.participantes.GetRange(0, vagas);
            mensagem = "Copiados os " + vagas + " Pokémon da cena aberta. Gerar cria outras cenas e novos confrontos; o torneio original é preservado.";
        }
        catch (ArgumentException erro)
        {
            mensagem = "Confira os filtros do tema da cena aberta: " + erro.Message;
        }
    }

    private void Gerar()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode) return;
        string lote = null;
        try
        {
            MigrarPreferencias();
            string origem = AssetDatabase.GetAssetPath(cenaBase);
            if (string.IsNullOrEmpty(origem) || !origem.EndsWith(".unity", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Escolha uma cena base salva.");
            if (temaBase == null) throw new InvalidOperationException("Escolha o tema base para copiar fontes, logos e peças da arena.");
            ResolverBiblioteca().ConferirBiblioteca();
            List<TipoPokemon> tipos = FiltrosPokemon.NormalizarTipos(tiposSelecionados);
            List<int> geracoes = FiltrosPokemon.NormalizarGeracoes(geracoesSelecionadas);
            if (quantidadeCenas < 1) throw new InvalidOperationException("Informe pelo menos uma cena.");
            semente = GeradorTorneiosPokemon.NovaSemente(semente);
            int vagas = tamanho == 0 ? 16 : 32;
            HashSet<string> anteriores = CarregarHistorico();
            List<PlanoTorneioPokemon> planos = selecaoManual
                ? GeradorTorneiosPokemon.PlanejarManualQuantidade(manuais.GetRange(0, Math.Min(vagas, manuais.Count)), vagas, tipos, geracoes, quantidadeCenas, semente, anteriores)
                : GeradorTorneiosPokemon.PlanejarQuantidade(catalogo, vagas, tipos, geracoes, quantidadeCenas, semente, anteriores);
            string id = DateTime.Now.ToString("yyyyMMdd_HHmmss") + "_" + Guid.NewGuid().ToString("N");
            lote = PastaLotes + "/Lote_" + id;
            Pasta(lote + "/Cenas"); Pasta(lote + "/Temas");
            var resumo = new StringBuilder("TORNEIOS POKÉMON\nSemente: " + semente +
                "\nGerações permitidas: " + string.Join(", ", geracoes) +
                "\nTipos permitidos: " + string.Join(", ", tipos.ConvertAll(t => t.ToString())) +
                "\nQuantidade solicitada: " + quantidadeCenas + "\nParticipantes por cena: " + vagas +
                "\nOrigem: " + (selecaoManual ? "Seleção manual" : "Sorteio pelo catálogo") + "\n\n");
            var linhas = new List<string> { "CENA,TIPO,GERACAO_TORNEIO,EDICAO,VAGA,POKEDEX,NOME,GERACAO_ESPECIE,TIPOS_PERMITIDOS,GERACOES_PERMITIDAS" };
            TemaCompeticao tema = null;
            string primeira = null;
            int concluidos = 0;
            for (int i = 0; i < planos.Count; i++)
            {
                PlanoTorneioPokemon plano = planos[i];
                if (EditorUtility.DisplayCancelableProgressBar("Gerando torneios Pokémon",
                    "Cena " + (i + 1) + " de " + planos.Count, i / (float)planos.Count))
                    throw new OperationCanceledException();
                if (tema == null) tema = CriarTema(plano, lote, id);
                string nome = "Torneio_" + plano.edicao.ToString("D3") + "_" + vagas;
                string destino = lote + "/Cenas/" + nome + ".unity";
                if (!AssetDatabase.CopyAsset(origem, destino)) throw new IOException("Não foi possível copiar a cena base.");
                ConfigurarCena(destino, plano, tema, id, vagas);
                // Só registra uma chave depois que sua cena foi validada e salva.
                File.AppendAllText(lote + "/" + ArquivoChaveamentos,
                    GeradorTorneiosPokemon.AssinaturaChaveamento(plano.participantes) + "\n", new UTF8Encoding(false));
                if (primeira == null) primeira = destino;
                concluidos++;
                resumo.AppendLine(nome + " · " + plano.participantes.Count + " participantes");
                for (int p = 0; p < plano.participantes.Count; p++)
                {
                    PokemonDados ficha = plano.participantes[p];
                    linhas.Add(nome + "," + plano.tipo + "," + plano.geracao + "," + plano.edicao + "," + (p + 1) + "," + ficha.numeroPokedex + ",\"" + ficha.nomePokemon.Replace("\"", "\"\"") + "\"," + ficha.Geracao +
                        ",\"" + string.Join("|", tipos.ConvertAll(t => t.ToString())) + "\",\"" + string.Join("|", geracoes) + "\"");
                }
                File.WriteAllText(lote + "/LEIA-ME.txt", resumo.ToString() + "\nCenas concluídas: " + concluidos + "/" + quantidadeCenas + ".\n", Encoding.UTF8);
                File.WriteAllLines(lote + "/participantes.csv", linhas, new UTF8Encoding(true));
                primeiraCena = primeira; pastaGerada = lote;
            }
            resumo.AppendLine("\nConcluído. Abra uma cena e dê Play. Cada edição tem seu próprio progresso.");
            File.WriteAllText(lote + "/LEIA-ME.txt", resumo.ToString(), Encoding.UTF8);
            AssetDatabase.SaveAssets(); AssetDatabase.Refresh();
            Selection.activeObject = AssetDatabase.LoadAssetAtPath<SceneAsset>(primeiraCena);
            mensagem = concluidos + " cena(s) criada(s) em " + lote + ". Semente usada: " + semente + ". Abra uma das cenas e dê Play.";
            Debug.Log(mensagem);
        }
        catch (Exception erro)
        {
            mensagem = (erro is OperationCanceledException ? "Geração cancelada." : "Geração interrompida: " + erro.Message) +
                (lote != null ? " Arquivos parciais em " + lote + ". As cenas originais foram preservadas." : "");
            Debug.LogWarning(mensagem);
        }
        finally { EditorUtility.ClearProgressBar(); AssetDatabase.Refresh(); }
    }

    private HashSet<string> CarregarHistorico()
    {
        var assinaturas = new HashSet<string>(StringComparer.Ordinal);
        if (!Directory.Exists(PastaLotes)) return assinaturas;
        foreach (string arquivo in Directory.GetFiles(PastaLotes, ArquivoChaveamentos, SearchOption.AllDirectories))
            foreach (string linha in File.ReadAllLines(arquivo))
            {
                string assinatura = linha.Trim().TrimStart('\uFEFF');
                if (assinatura.Length == 0) continue;
                if (assinatura.Length != 64 || !AssinaturaHexadecimal(assinatura))
                    throw new InvalidDataException("O histórico de chaveamentos está inválido em " + arquivo +
                        ". Restaure esse arquivo antes de gerar para preservar a proteção contra repetições.");
                assinaturas.Add(assinatura);
            }
        // Os lotes antigos não possuem chaveamentos.txt; os CSVs preservam a ordem dos pares.
        var porNumero = new Dictionary<int, PokemonDados>();
        foreach (PokemonDados ficha in catalogo)
            if (ficha != null && !porNumero.ContainsKey(ficha.numeroPokedex)) porNumero.Add(ficha.numeroPokedex, ficha);
        foreach (string arquivo in Directory.GetFiles(PastaLotes, "participantes.csv", SearchOption.AllDirectories))
            ImportarChaveamentosCsv(arquivo, porNumero, assinaturas);
        return assinaturas;
    }

    private static void ImportarChaveamentosCsv(string arquivo, Dictionary<int, PokemonDados> catalogo,
        HashSet<string> assinaturas)
    {
        var cenas = new Dictionary<string, SortedDictionary<int, PokemonDados>>(StringComparer.Ordinal);
        var invalidas = new HashSet<string>(StringComparer.Ordinal);
        foreach (string linha in LerRegistrosCsv(arquivo))
        {
            List<string> colunas = PrimeirasColunasCsv(linha, 6);
            int vaga, numero;
            if (colunas.Count < 6 || !int.TryParse(colunas[4], NumberStyles.Integer, CultureInfo.InvariantCulture, out vaga) ||
                !int.TryParse(colunas[5], NumberStyles.Integer, CultureInfo.InvariantCulture, out numero)) continue;
            string cena = colunas[0];
            if (string.IsNullOrEmpty(cena)) continue;
            SortedDictionary<int, PokemonDados> participantes;
            if (!cenas.TryGetValue(cena, out participantes))
            {
                participantes = new SortedDictionary<int, PokemonDados>();
                cenas.Add(cena, participantes);
            }
            PokemonDados ficha;
            if (vaga < 1 || vaga > 32 || !catalogo.TryGetValue(numero, out ficha) || participantes.ContainsKey(vaga))
                invalidas.Add(cena);
            else participantes.Add(vaga, ficha);
        }
        foreach (var cena in cenas)
        {
            int total = cena.Value.Count;
            string nome = Path.GetFileNameWithoutExtension(cena.Key);
            int vagas = nome.EndsWith("_16", StringComparison.Ordinal) ? 16 :
                nome.EndsWith("_32", StringComparison.Ordinal) ? 32 : 0;
            if (invalidas.Contains(cena.Key) || vagas == 0 || total != vagas) continue;
            var ordem = new List<PokemonDados>();
            for (int i = 1; i <= total; i++)
            {
                PokemonDados ficha;
                if (!cena.Value.TryGetValue(i, out ficha)) { ordem.Clear(); break; }
                ordem.Add(ficha);
            }
            if (ordem.Count != total) continue;
            try { assinaturas.Add(GeradorTorneiosPokemon.AssinaturaChaveamento(ordem)); }
            catch (ArgumentException) { /* Uma linha antiga incompleta não representa uma chave válida. */ }
        }
    }

    private static bool AssinaturaHexadecimal(string assinatura)
    {
        foreach (char c in assinatura)
            if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
                return false;
        return true;
    }

    private static IEnumerable<string> LerRegistrosCsv(string arquivo)
    {
        using (var leitor = new StreamReader(arquivo, Encoding.UTF8, true))
        {
            var registro = new StringBuilder();
            bool aspas = false;
            string linha;
            while ((linha = leitor.ReadLine()) != null)
            {
                if (registro.Length > 0) registro.Append('\n');
                registro.Append(linha);
                for (int i = 0; i < linha.Length; i++)
                    if (linha[i] == '"')
                    {
                        if (aspas && i + 1 < linha.Length && linha[i + 1] == '"') i++;
                        else aspas = !aspas;
                    }
                if (!aspas)
                {
                    yield return registro.ToString();
                    registro.Length = 0;
                }
            }
        }
    }

    private static List<string> PrimeirasColunasCsv(string linha, int quantidade)
    {
        var resultado = new List<string>();
        var coluna = new StringBuilder();
        bool aspas = false;
        for (int i = 0; i < linha.Length && resultado.Count < quantidade; i++)
        {
            char c = linha[i];
            if (c == '"')
            {
                if (aspas && i + 1 < linha.Length && linha[i + 1] == '"') { coluna.Append('"'); i++; }
                else aspas = !aspas;
            }
            else if (c == ',' && !aspas) { resultado.Add(coluna.ToString()); coluna.Length = 0; }
            else coluna.Append(c);
        }
        if (resultado.Count < quantidade && !aspas) resultado.Add(coluna.ToString());
        return resultado;
    }

    private void ConfigurarCena(string caminho, PlanoTorneioPokemon plano, TemaCompeticao tema, string loteId, int vagas)
    {
        Scene cena = EditorSceneManager.OpenScene(caminho, OpenSceneMode.Additive);
        try
        {
            TorneioPokemon torneio = null;
            foreach (GameObject raiz in cena.GetRootGameObjects())
                foreach (TorneioPokemon candidato in raiz.GetComponentsInChildren<TorneioPokemon>(true))
                {
                    if (torneio != null) throw new InvalidOperationException("A cena base contém mais de um TorneioPokemon.");
                    torneio = candidato;
                }
            if (torneio == null) throw new InvalidOperationException("A cena base precisa conter TorneioPokemon.");
            torneio.tema = tema;
            torneio.edicaoId = "lote_" + loteId + "_" + vagas + "_" + plano.edicao.ToString("D3");
            torneio.tamanhoChave = vagas == 16 ? TamanhoMataMata.Oitavas : TamanhoMataMata.DezesseisAvos;
            torneio.participantes = new List<PokemonDados>(plano.participantes);
            torneio.distribuicao = DistribuicaoMataMata.ConfrontosNaOrdemDaLista;
            torneio.sortearParticipantes = false;
            torneio.sementeSorteio = semente;
            torneio.permitirFolgas = false;
            torneio.salvarProgresso = salvarProgresso;
            torneio.gravarSomenteUmaFase = somenteUmaFase;
            torneio.ultimoErro = "";
            if (torneio.gerenciador != null) torneio.gerenciador.logoCampeonato = tema.logoCompeticao;
            ArenaPokemon arena = torneio.GetComponent<ArenaPokemon>();
            if (arena != null)
            {
                arena.tema = tema;
                if (arena.campo != null) { arena.campo.sprite = tema.campo; arena.campo.color = Color.white; }
                if (arena.helice2 != null) arena.helice2.color = tema.tintHelice;
                if (arena.gol != null) arena.gol.color = tema.tintGol;
                EditorUtility.SetDirty(arena);
            }
            PokemonHUD hud = torneio.GetComponent<PokemonHUD>();
            if (hud != null) { hud.tema = tema; EditorUtility.SetDirty(hud); }
            if (!torneio.ValidarConfiguracao()) throw new InvalidOperationException(torneio.ultimoErro);
            EditorUtility.SetDirty(torneio);
            EditorSceneManager.MarkSceneDirty(cena);
            if (!EditorSceneManager.SaveScene(cena)) throw new IOException("Não foi possível salvar " + caminho);
        }
        finally { EditorSceneManager.CloseScene(cena, true); }
    }

    private TemaCompeticao CriarTema(PlanoTorneioPokemon plano, string lote, string loteId)
    {
        var tema = UnityEngine.Object.Instantiate(temaBase);
        try
        {
            TipoPokemon tipoEscolhido = plano.tipo;
            int hex = FundosTiposPokemon.CorDestaque(tipoEscolhido);
            Color destaque = new Color(((hex >> 16) & 255) / 255f, ((hex >> 8) & 255) / 255f, (hex & 255) / 255f);
            tema.name = "Tema_Filtros";
            tema.competicaoId = "pokemon_auto_" + loteId.Substring(loteId.Length - 16);
            tema.usarFiltrosMultiplosPokemon = true;
            tema.tiposPokemonPermitidos = new List<TipoPokemon>(plano.tiposPermitidos);
            tema.geracoesPokemonPermitidas = new List<int>(plano.geracoesPermitidas);
            tema.geracaoPokemonPermitida = plano.geracao;
            tema.filtrarPorTipoPokemon = tipoEscolhido != TipoPokemon.Nenhum;
            tema.tipoPokemonPermitido = tipoEscolhido;
            tema.nomeCompeticao = BibliotecaFundosPokemon.TituloEmIngles(tema);
            tema.corDestaque = destaque;
            tema.corPrimaria = Color.Lerp(new Color(0.015f, 0.025f, 0.055f), destaque, 0.08f);
            tema.corSecundaria = Color.Lerp(Color.black, destaque, 0.35f);
            tema.corPainel = Color.Lerp(Color.black, destaque, 0.07f);
            tema.corTexto = Color.white;
            tema.tintGol = destaque; tema.tintHelice = destaque;
            tema.tintCampo = Color.white; tema.tintFundoArena = tema.corPrimaria;
            ResolverBiblioteca().AplicarAoTema(tema);
            AssetDatabase.CreateAsset(tema, lote + "/Temas/" + tema.name + ".asset");
            return tema;
        }
        catch
        {
            if (!EditorUtility.IsPersistent(tema)) UnityEngine.Object.DestroyImmediate(tema);
            throw;
        }
    }

    private BibliotecaFundosPokemon ResolverBiblioteca()
    {
        if (biblioteca == null) biblioteca = ProcurarBibliotecaInstalada();
        if (biblioteca == null)
            throw new InvalidOperationException("Instale a biblioteca de fundos ilustrados e aguarde a importação, ou atribua-a ao campo Fundos ilustrados.");
        return biblioteca;
    }

    private static BibliotecaFundosPokemon ProcurarBibliotecaInstalada()
    {
        var fonte = AssetDatabase.LoadAssetAtPath<BibliotecaFundosPokemon>(CaminhoBiblioteca);
        if (fonte != null) return fonte;
        string[] encontrados = AssetDatabase.FindAssets("t:BibliotecaFundosPokemon");
        return encontrados.Length == 1
            ? AssetDatabase.LoadAssetAtPath<BibliotecaFundosPokemon>(AssetDatabase.GUIDToAssetPath(encontrados[0]))
            : null;
    }

    private void AtualizarLotesExistentes()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode) return;
        try
        {
            BibliotecaFundosPokemon fonte = ResolverBiblioteca();
            fonte.ConferirBiblioteca();
            if (!AssetDatabase.IsValidFolder(PastaLotes))
            {
                mensagem = "Ainda não há lotes gerados. Os próximos já usarão os fundos ilustrados e títulos em inglês.";
                return;
            }
            var temas = new List<TemaCompeticao>();
            foreach (string guid in AssetDatabase.FindAssets("t:TemaCompeticao", new[] { PastaLotes }))
            {
                TemaCompeticao tema = AssetDatabase.LoadAssetAtPath<TemaCompeticao>(AssetDatabase.GUIDToAssetPath(guid));
                if (tema == null || string.IsNullOrEmpty(tema.competicaoId) ||
                    !tema.competicaoId.StartsWith("pokemon_auto_", StringComparison.Ordinal)) continue;
                tema.ConferirFiltrosPokemon();
                TipoPokemon tipoDoTema = tema.TipoVisualPokemon;
                fonte.Obter(tipoDoTema); fonte.Obter(tipoDoTema, true);
                BibliotecaFundosPokemon.TituloEmIngles(tema);
                temas.Add(tema);
            }
            foreach (TemaCompeticao tema in temas)
            {
                Undo.RecordObject(tema, "Aplicar fundo ilustrado e título em inglês");
                fonte.AplicarAoTema(tema);
                EditorUtility.SetDirty(tema);
            }
            AssetDatabase.SaveAssets();
            mensagem = temas.Count + " temas atualizados. Participantes, confrontos, filtros e IDs foram preservados.";
            Debug.Log(mensagem);
        }
        catch (Exception erro) { mensagem = "Não foi possível atualizar os temas: " + erro.Message; Debug.LogWarning(mensagem); }
    }

    [MenuItem("Assets/Pokémon/Aplicar fundo ilustrado e título em inglês")]
    private static void AplicarFundoAoTemaSelecionado()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode) return;
        TemaCompeticao tema = Selection.activeObject as TemaCompeticao;
        if (tema == null) return;
        try
        {
            BibliotecaFundosPokemon fonte = ProcurarBibliotecaInstalada();
            if (fonte == null) throw new InvalidOperationException("Instale a biblioteca de fundos ilustrados.");
            tema.ConferirFiltrosPokemon();
            TipoPokemon tipoDoTema = tema.TipoVisualPokemon;
            fonte.Obter(tipoDoTema); fonte.Obter(tipoDoTema, true);
            Undo.RecordObject(tema, "Aplicar fundo ilustrado e título em inglês");
            fonte.AplicarAoTema(tema);
            EditorUtility.SetDirty(tema); AssetDatabase.SaveAssets();
            Debug.Log("Fundo ilustrado e título em inglês aplicados. Inicie o Play para conferir.", tema);
        }
        catch (Exception erro) { Debug.LogError("Fundos Pokémon: " + erro.Message); }
    }

    [MenuItem("Assets/Pokémon/Aplicar fundo ilustrado e título em inglês", true)]
    private static bool PodeAplicarFundo()
    {
        return !EditorApplication.isPlayingOrWillChangePlaymode && Selection.activeObject is TemaCompeticao;
    }

    private static void Pasta(string caminho)
    {
        string[] partes = caminho.Split('/');
        string pai = partes[0];
        for (int i = 1; i < partes.Length; i++)
        {
            string atual = pai + "/" + partes[i];
            if (!AssetDatabase.IsValidFolder(atual)) AssetDatabase.CreateFolder(pai, partes[i]);
            pai = atual;
        }
    }
}
#endif
