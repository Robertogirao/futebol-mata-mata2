using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEngine;

/// <summary>Pokemon-facing configuration; the original tournament engine stays internal.</summary>
[DefaultExecutionOrder(-300)]
[DisallowMultipleComponent]
public sealed class TorneioPokemon : MonoBehaviour
{
    [Header("Identidade do torneio")]
    public TemaCompeticao tema;
    public string edicaoId = "temporada_01";

    [Header("Pokémon participantes")]
    [Tooltip("Use Oitavas para 16 ou Dezesseis Avos para 32. São usadas as primeiras posições da lista.")]
    public TamanhoMataMata tamanhoChave = TamanhoMataMata.Oitavas;
    public List<PokemonDados> participantes = new List<PokemonDados>();
    public DistribuicaoMataMata distribuicao = DistribuicaoMataMata.ConfrontosNaOrdemDaLista;
    public bool permitirFolgas = false;
    public bool sortearParticipantes = false;
    public int sementeSorteio = 2026;

    [Header("Gravação e continuidade")]
    public bool salvarProgresso = false;
    public bool gravarSomenteUmaFase = true;
    [Min(1f)] public float duracaoPartida = 45f;
    [Min(3f)] public float tempoInicio = 15f;
    [Min(3f)] public float tempoPreJogo = 10f;
    [Min(3f)] public float tempoFinal = 20f;

    [Header("Regravar uma partida salva")]
    [Min(1)] public int faseParaRegravar = 1;
    [Min(1)] public int jogoParaRegravar = 1;

    [HideInInspector]
    public TournamentManager gerenciador;
    [HideInInspector]
    public MataMataCampeonato motorMataMata;
    [HideInInspector]
    public UniversalUI interfacePartida;

    [Header("Diagnóstico")]
    [TextArea(2, 5)] public string ultimoErro;

    private readonly List<TeamData> fichasTemporarias = new List<TeamData>();
    private bool preparado;

    public int Vagas { get { return (int)tamanhoChave; } }
    public bool Ocupado { get { return motorMataMata != null && motorMataMata.Ocupado; } }

    public string PastaTorneio
    {
        get
        {
            Exigir(tema != null && tema.PossuiIdentificadorValido(), "Escolha um tema com identificador válido.");
            Exigir(IdentificadorValido(edicaoId), "Edição aceita de 1 a 80 letras, números, _ e -.");
            return Path.Combine(Application.persistentDataPath, "MataMata", tema.competicaoId, edicaoId);
        }
    }

    private void Awake()
    {
        ResolverReferencias();
        if (!Tentar(PrepararMotor) && gerenciador != null)
            gerenciador.enabled = false;
    }

    private void ResolverReferencias()
    {
        if (gerenciador == null) gerenciador = GetComponent<TournamentManager>();
        if (motorMataMata == null) motorMataMata = GetComponent<MataMataCampeonato>();
        if (interfacePartida == null) interfacePartida = FindFirstObjectByType<UniversalUI>();
    }

    public bool ValidarConfiguracao()
    {
        return Tentar(() => ConferirParticipantes());
    }

    public int ContarParticipantesPreenchidos()
    {
        int total = 0;
        if (participantes == null) return total;
        int limite = Math.Min(Vagas, participantes.Count);
        for (int i = 0; i < limite; i++)
            if (participantes[i] != null) total++;
        return total;
    }

    private List<PokemonDados> ConferirParticipantes()
    {
        string pasta = PastaTorneio;
        Exigir(Vagas == 16 || Vagas == 32, "Escolha Oitavas (16) ou Dezesseis Avos (32).");
        Exigir(Enum.IsDefined(typeof(DistribuicaoMataMata), distribuicao), "Distribuição da chave inválida.");
        Exigir(TempoValido(duracaoPartida, 1f) && TempoValido(tempoInicio, 3f) &&
            TempoValido(tempoPreJogo, 3f) && TempoValido(tempoFinal, 3f),
            "Confira os tempos: partida mínima de 1 segundo; apresentações mínimas de 3 segundos.");

        var usados = new List<PokemonDados>();
        tema.ConferirFiltrosPokemon();
        var ids = new HashSet<string>(StringComparer.Ordinal);
        int limite = participantes == null ? 0 : Math.Min(Vagas, participantes.Count);
        for (int i = 0; i < limite; i++)
        {
            PokemonDados pokemon = participantes[i];
            if (pokemon == null) continue;
            pokemon.ExigirValido();
            Exigir(ids.Add(pokemon.IdEstavel), "Pokémon repetido na chave: " + pokemon.nomePokemon + ".");
            Exigir(tema.PermitePokemon(pokemon),
                pokemon.nomePokemon + " não atende aos filtros de tipos e gerações do tema.");
            usados.Add(pokemon);
        }
        Exigir(usados.Count >= 2, "Cadastre pelo menos dois Pokémon.");
        Exigir(permitirFolgas || usados.Count == Vagas,
            "Faltam " + (Vagas - usados.Count) + " Pokémon para a chave de " + Vagas + ".");
        return usados;
    }

    private void PrepararMotor()
    {
        Exigir(!Application.isPlaying || !preparado || !Ocupado,
            "Aguarde a partida terminar antes de reconfigurar o torneio.");
        ResolverReferencias();
        Exigir(gerenciador != null && motorMataMata != null,
            "Confira TournamentManager e MataMataCampeonato nos componentes internos.");
        Exigir(interfacePartida != null, "Confira a interface da partida.");
        List<PokemonDados> usados = ConferirParticipantes();
        var novas = new List<TeamData>();
        try
        {
            foreach (PokemonDados pokemon in usados) novas.Add(pokemon.CriarFichaDeJogo());
        }
        catch
        {
            foreach (TeamData ficha in novas) DestruirTemporario(ficha);
            throw;
        }

        LiberarFichas();
        fichasTemporarias.AddRange(novas);
        motorMataMata.tema = tema;
        motorMataMata.edicaoId = edicaoId;
        motorMataMata.tamanhoChave = tamanhoChave;
        motorMataMata.participantes = new List<TeamData>(fichasTemporarias);
        motorMataMata.distribuicao = distribuicao;
        motorMataMata.permitirFolgas = permitirFolgas;
        motorMataMata.sortearParticipantes = sortearParticipantes;
        motorMataMata.sementeSorteio = sementeSorteio;
        motorMataMata.salvarProgresso = salvarProgresso;
        motorMataMata.gravarSomenteUmaFase = gravarSomenteUmaFase;
        motorMataMata.tempoInicio = tempoInicio;
        motorMataMata.tempoPreJogo = tempoPreJogo;
        motorMataMata.tempoFinal = tempoFinal;
        motorMataMata.faseParaRegravar = faseParaRegravar;
        motorMataMata.jogoParaRegravar = jogoParaRegravar;

        gerenciador.modoMataMata = true;
        gerenciador.mataMata = motorMataMata;
        gerenciador.modoLiga = false;
        gerenciador.mostrarClassificacao = false;
        gerenciador.mostrarAbertura = false;
        gerenciador.logoCampeonato = tema.logoCompeticao;
        gerenciador.todosOsTimesDisponiveis = new List<TeamData>();
        interfacePartida.duracaoRealEmSegundos = duracaoPartida;
        interfacePartida.ativarGoldenGoal = true;
        preparado = true;
    }

    [ContextMenu("Pokémon/Continuar próxima fase no Play")]
    public void ContinuarNoPlay()
    {
        if (!Application.isPlaying || !preparado || motorMataMata == null) return;
        motorMataMata.ContinuarNoPlay();
    }

    [ContextMenu("Pokémon/Tentar salvar último resultado")]
    public void TentarSalvarUltimoResultado()
    {
        if (Application.isPlaying && gerenciador != null)
            gerenciador.TentarSalvarUltimoResultado();
    }

    [ContextMenu("Pokémon/Regravar partida selecionada")]
    private void MenuRegravarPartida() { RegravarPartida(); }

    public bool RegravarPartida()
    {
        return ExecutarForaDoPlay(() =>
        {
            Exigir(salvarProgresso, "Ative Salvar Progresso para reabrir um resultado salvo.");
            Exigir(motorMataMata.RegravarPartida(), motorMataMata.ultimoErro);
        });
    }

    [ContextMenu("Pokémon/Arquivar progresso e iniciar novo torneio")]
    private void MenuArquivar() { ArquivarTorneio(); }

    public bool ArquivarTorneio()
    {
        return Tentar(() =>
        {
            Exigir(!Application.isPlaying, "Saia do Play antes de arquivar o progresso.");
            ResolverReferencias();
            Exigir(motorMataMata != null, "Confira o motor do mata-mata.");
            string pasta = PastaTorneio;
            motorMataMata.tema = tema;
            motorMataMata.edicaoId = edicaoId;
            Exigir(motorMataMata.NovoTorneio(), motorMataMata.ultimoErro);
        });
    }

    private bool ExecutarForaDoPlay(Action acao)
    {
        if (Application.isPlaying)
        {
            ultimoErro = "Saia do Play antes de editar o progresso salvo.";
            Debug.LogWarning(ultimoErro, this);
            return false;
        }
        ResolverReferencias();
        List<TeamData> anteriores = motorMataMata != null ? motorMataMata.participantes : null;
        bool ok = Tentar(() => { PrepararMotor(); acao(); });
        if (motorMataMata != null) motorMataMata.participantes = anteriores;
        LiberarFichas();
        preparado = false;
        return ok;
    }

    private void OnDestroy()
    {
        if (motorMataMata != null) motorMataMata.CancelarApresentacao();
        LiberarFichas();
    }

    private void LiberarFichas()
    {
        foreach (TeamData ficha in fichasTemporarias) DestruirTemporario(ficha);
        fichasTemporarias.Clear();
    }

    private static void DestruirTemporario(TeamData ficha)
    {
        if (ficha == null) return;
        if (Application.isPlaying) Destroy(ficha);
        else DestroyImmediate(ficha);
    }

    private bool Tentar(Action acao)
    {
        ultimoErro = "";
        try { acao(); return true; }
        catch (Exception erro)
        {
            ultimoErro = erro.Message;
            Debug.LogError("Pokémon: " + erro.Message, this);
            return false;
        }
    }

    private static bool IdentificadorValido(string valor)
    {
        return !string.IsNullOrEmpty(valor) && Regex.IsMatch(valor, @"\A[A-Za-z0-9_-]{1,80}\z");
    }

    private static bool TempoValido(float valor, float minimo)
    {
        return !float.IsNaN(valor) && !float.IsInfinity(valor) && valor >= minimo;
    }

    private static void Exigir(bool condicao, string mensagem)
    {
        if (!condicao) throw new InvalidOperationException(mensagem);
    }
}
