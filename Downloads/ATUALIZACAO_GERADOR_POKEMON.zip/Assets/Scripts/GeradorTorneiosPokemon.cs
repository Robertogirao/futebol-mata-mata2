using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

/// <summary>Planejamento de torneios sem alterar fichas, cenas ou progresso.</summary>
public sealed class PlanoTorneioPokemon
{
    public TipoPokemon tipo;
    public int geracao;
    public int edicao;
    public List<PokemonDados> participantes;
    public List<TipoPokemon> tiposPermitidos;
    public List<int> geracoesPermitidas;
}

public static class GeradorTorneiosPokemon
{
    public static List<PokemonDados> ConferirCatalogo(IEnumerable<PokemonDados> fichas)
    {
        if (fichas == null) throw new ArgumentException("Carregue as fichas Pokémon.");
        var resultado = new List<PokemonDados>();
        var ids = new HashSet<string>(StringComparer.Ordinal);
        foreach (PokemonDados ficha in fichas)
        {
            if (ficha == null) continue;
            ficha.ExigirValido();
            if (!ids.Add(ficha.IdEstavel))
                throw new ArgumentException("Há fichas repetidas para a espécie " + ficha.numeroPokedex + ".");
            resultado.Add(ficha);
        }
        resultado.Sort((a, b) => a.numeroPokedex.CompareTo(b.numeroPokedex));
        return resultado;
    }

    public static int ContarElegiveis(IEnumerable<PokemonDados> fichas, TipoPokemon tipo, int geracao = 0)
    {
        ConferirTipo(tipo);
        ConferirGeracao(geracao);
        int total = 0;
        if (fichas != null)
            foreach (PokemonDados ficha in fichas)
                if (ficha != null && ficha.PertenceAoTipo(tipo) && ficha.PertenceAGeracao(geracao)) total++;
        return total;
    }

    public static int ContarElegiveis(IEnumerable<PokemonDados> fichas,
        IEnumerable<TipoPokemon> tipos, IEnumerable<int> geracoes)
    {
        List<TipoPokemon> tiposValidos = FiltrosPokemon.NormalizarTipos(tipos);
        List<int> geracoesValidas = FiltrosPokemon.NormalizarGeracoes(geracoes);
        var ids = new HashSet<string>(StringComparer.Ordinal);
        if (fichas != null)
            foreach (PokemonDados ficha in fichas)
                if (FiltrosPokemon.Permite(ficha, tiposValidos, geracoesValidas))
                    ids.Add(ficha.IdEstavel);
        return ids.Count;
    }

    /// <summary>
    /// Sorteia uma quantidade exata de chaves a partir de um único conjunto de
    /// elegíveis. Não repete espécies na mesma chave nem confrontos registrados.
    /// </summary>
    public static List<PlanoTorneioPokemon> PlanejarQuantidade(IEnumerable<PokemonDados> fichas,
        int vagas, IEnumerable<TipoPokemon> tipos, IEnumerable<int> geracoes,
        int quantidade, int semente, IEnumerable<string> assinaturasAnteriores = null)
    {
        ConferirVagas(vagas);
        if (quantidade < 1) throw new ArgumentException("Escolha pelo menos uma cena para gerar.");
        List<TipoPokemon> tiposValidos = FiltrosPokemon.NormalizarTipos(tipos);
        List<int> geracoesValidas = FiltrosPokemon.NormalizarGeracoes(geracoes);
        List<PokemonDados> catalogo = ConferirCatalogo(fichas);
        var elegiveis = new List<PokemonDados>();
        foreach (PokemonDados ficha in catalogo)
            if (FiltrosPokemon.Permite(ficha, tiposValidos, geracoesValidas))
                elegiveis.Add(ficha);

        if (elegiveis.Count < vagas)
            throw new ArgumentException("Os filtros selecionados têm " + elegiveis.Count +
                " Pokémon elegíveis, mas cada cena precisa de " + vagas +
                ". Marque mais gerações ou tipos.");
        if (quantidade > MaximoDeChaveamentos(elegiveis.Count, vagas))
            throw new ArgumentException("A quantidade solicitada excede os conjuntos de confrontos " +
                "possíveis com esses participantes. Gere menos cenas ou amplie os filtros.");

        var usadas = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (assinaturasAnteriores != null)
            foreach (string assinatura in assinaturasAnteriores)
                if (!string.IsNullOrWhiteSpace(assinatura)) usadas.Add(assinatura.Trim());

        var planos = new List<PlanoTorneioPokemon>();
        var sorteio = new Random(semente);
        const int limiteDeTentativasPorCena = 8192;
        for (int cena = 0; cena < quantidade; cena++)
        {
            List<PokemonDados> escolhidos = null;
            for (int tentativa = 0; tentativa < limiteDeTentativasPorCena; tentativa++)
            {
                var ordem = new List<PokemonDados>(elegiveis);
                Embaralhar(ordem, sorteio);
                var candidatos = ordem.GetRange(0, vagas);
                if (!usadas.Add(AssinaturaChaveamento(candidatos))) continue;
                escolhidos = candidatos;
                break;
            }
            if (escolhidos == null)
                throw new InvalidOperationException("Não foi possível encontrar um chaveamento novo " +
                    "para todas as cenas solicitadas. Nenhum confronto repetido foi aceito. " +
                    "Amplie os filtros ou reduza a quantidade de cenas.");

            planos.Add(new PlanoTorneioPokemon
            {
                tipo = tiposValidos.Count == 1 ? tiposValidos[0] : TipoPokemon.Nenhum,
                geracao = geracoesValidas.Count == 1 ? geracoesValidas[0] : 0,
                tiposPermitidos = new List<TipoPokemon>(tiposValidos),
                geracoesPermitidas = new List<int>(geracoesValidas),
                edicao = cena + 1,
                participantes = escolhidos
            });
        }
        return planos;
    }

    public static List<PlanoTorneioPokemon> PlanejarManualQuantidade(IEnumerable<PokemonDados> fichas,
        int vagas, IEnumerable<TipoPokemon> tipos, IEnumerable<int> geracoes,
        int quantidade, int semente, IEnumerable<string> assinaturasAnteriores = null)
    {
        ConferirVagas(vagas);
        var escolhidos = fichas != null ? new List<PokemonDados>(fichas) : new List<PokemonDados>();
        if (escolhidos.Count != vagas || escolhidos.Exists(ficha => ficha == null))
            throw new ArgumentException("Preencha exatamente " + vagas + " Pokémon na seleção manual.");
        List<TipoPokemon> tiposValidos = FiltrosPokemon.NormalizarTipos(tipos);
        List<int> geracoesValidas = FiltrosPokemon.NormalizarGeracoes(geracoes);
        foreach (PokemonDados ficha in escolhidos)
            if (!FiltrosPokemon.Permite(ficha, tiposValidos, geracoesValidas))
                throw new ArgumentException(ficha.nomePokemon + " não atende às gerações e aos tipos marcados.");
        return PlanejarQuantidade(escolhidos, vagas, tiposValidos, geracoesValidas,
            quantidade, semente, assinaturasAnteriores);
    }

    /// <summary>
    /// Identifica os pares iniciais, ignorando a troca de lados e a ordem dos jogos.
    /// Só inverter A/B ou mover um jogo de lugar não constitui um sorteio novo.
    /// </summary>
    public static string AssinaturaChaveamento(IEnumerable<PokemonDados> participantes)
    {
        var ordem = participantes != null ? new List<PokemonDados>(participantes) : new List<PokemonDados>();
        ConferirVagas(ordem.Count);
        var ids = new HashSet<string>(StringComparer.Ordinal);
        var pares = new List<string>();
        for (int i = 0; i < ordem.Count; i += 2)
        {
            PokemonDados a = ordem[i], b = ordem[i + 1];
            if (a == null || b == null || a.numeroPokedex <= 0 || b.numeroPokedex <= 0 ||
                !ids.Add(a.IdEstavel) || !ids.Add(b.IdEstavel))
                throw new ArgumentException("A chave deve conter espécies válidas, sem vagas vazias ou repetidas.");
            string idA = a.IdEstavel, idB = b.IdEstavel;
            pares.Add(string.CompareOrdinal(idA, idB) < 0 ? idA + ":" + idB : idB + ":" + idA);
        }
        pares.Sort(StringComparer.Ordinal);
        byte[] bytes = Encoding.UTF8.GetBytes(ordem.Count + "|" + string.Join("|", pares.ToArray()));
        using (SHA256 hash = SHA256.Create())
        {
            byte[] digest = hash.ComputeHash(bytes);
            var texto = new StringBuilder(digest.Length * 2);
            foreach (byte valor in digest) texto.Append(valor.ToString("x2"));
            return texto.ToString();
        }
    }

    private static double MaximoDeChaveamentos(int elegiveis, int vagas)
    {
        double grupos = 1d;
        for (int i = 1; i <= vagas; i++) grupos *= (elegiveis - vagas + i) / (double)i;
        double pares = 1d;
        for (int i = vagas - 1; i > 1; i -= 2) pares *= i;
        return grupos * pares;
    }

    public static List<PlanoTorneioPokemon> Planejar(IEnumerable<PokemonDados> fichas,
        int vagas, TipoPokemon tipo, bool todosOsTipos, bool maximoSemRepetir, int semente,
        int geracao = 0, bool separarGeracoes = false)
    {
        ConferirVagas(vagas);
        ConferirTipo(tipo);
        ConferirGeracao(geracao);
        if (separarGeracoes && geracao != 0)
            throw new ArgumentException("Para separar todas as gerações, use o filtro de geração zero.");
        List<PokemonDados> catalogo = ConferirCatalogo(fichas);
        var planos = new List<PlanoTorneioPokemon>();
        int inicio = todosOsTipos ? 1 : (int)tipo;
        int fim = todosOsTipos ? 18 : (int)tipo;
        int inicioGeracao = separarGeracoes ? 1 : geracao;
        int fimGeracao = separarGeracoes ? 9 : geracao;
        for (int g = inicioGeracao; g <= fimGeracao; g++)
        for (int t = inicio; t <= fim; t++)
        {
            var elegiveis = new List<PokemonDados>();
            foreach (PokemonDados ficha in catalogo)
                if (ficha.PertenceAoTipo((TipoPokemon)t) && ficha.PertenceAGeracao(g)) elegiveis.Add(ficha);
            Embaralhar(elegiveis, unchecked(semente + t * 7919 + g * 104729));
            int quantidade = maximoSemRepetir ? elegiveis.Count / vagas : (elegiveis.Count >= vagas ? 1 : 0);
            for (int e = 0; e < quantidade; e++)
                planos.Add(new PlanoTorneioPokemon
                {
                    tipo = (TipoPokemon)t,
                    geracao = g,
                    edicao = e + 1,
                    participantes = elegiveis.GetRange(e * vagas, vagas)
                });
        }
        if (planos.Count == 0)
            throw new ArgumentException("Não há Pokémon suficientes para uma chave completa de " + vagas + ".");
        return planos;
    }

    public static PlanoTorneioPokemon PlanejarManual(IEnumerable<PokemonDados> fichas,
        int vagas, TipoPokemon tipo, int geracao = 0, bool embaralhar = false, int semente = 0)
    {
        ConferirVagas(vagas);
        ConferirTipo(tipo);
        ConferirGeracao(geracao);
        // Trabalha numa cópia para manter as fichas e a lista manual intactas.
        var ordem = new List<PokemonDados>();
        if (fichas != null) ordem.AddRange(fichas);
        if (ordem.Count != vagas)
            throw new ArgumentException("Escolha exatamente " + vagas + " Pokémon na seleção manual.");
        List<PokemonDados> validos = ConferirCatalogo(ordem);
        if (validos.Count != vagas)
            throw new ArgumentException("Preencha todas as vagas da seleção manual.");
        foreach (PokemonDados ficha in ordem)
        {
            if (!ficha.PertenceAoTipo(tipo) || !ficha.PertenceAGeracao(geracao))
                throw new ArgumentException(ficha.nomePokemon + " não atende aos filtros de tipo e geração.");
        }
        if (embaralhar) Embaralhar(ordem, unchecked(semente + (int)tipo * 7919 + geracao * 104729));
        return new PlanoTorneioPokemon { tipo = tipo, geracao = geracao, edicao = 1, participantes = ordem };
    }

    public static int NovaSemente(int anterior)
    {
        int nova = Guid.NewGuid().GetHashCode() & int.MaxValue;
        return nova == (anterior & int.MaxValue) ? (nova == int.MaxValue ? 0 : nova + 1) : nova;
    }

    private static void Embaralhar(List<PokemonDados> fichas, int semente)
    {
        Embaralhar(fichas, new Random(semente));
    }

    private static void Embaralhar(List<PokemonDados> fichas, Random sorteio)
    {
        for (int i = fichas.Count - 1; i > 0; i--)
        {
            int j = sorteio.Next(i + 1);
            PokemonDados atual = fichas[i]; fichas[i] = fichas[j]; fichas[j] = atual;
        }
    }

    private static void ConferirGeracao(int geracao)
    {
        if (geracao < 0 || geracao > 9) throw new ArgumentException("Escolha uma geração de 1 a 9 ou todas (zero).");
    }

    private static void ConferirTipo(TipoPokemon tipo)
    {
        if (!Enum.IsDefined(typeof(TipoPokemon), tipo)) throw new ArgumentException("Tipo Pokémon inválido.");
    }

    private static void ConferirVagas(int vagas)
    {
        if (vagas != 16 && vagas != 32) throw new ArgumentException("Escolha 16 ou 32 participantes.");
    }
}
