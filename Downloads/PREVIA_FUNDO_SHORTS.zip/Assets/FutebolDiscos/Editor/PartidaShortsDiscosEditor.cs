using UnityEditor;
using UnityEditor.Sprites;
using UnityEngine;

namespace FutebolDeDiscos
{
    [CustomEditor(typeof(PartidaShortsDiscos)), CanEditMultipleObjects]
    public sealed class PartidaShortsDiscosEditor : Editor
    {
        private const float Aspecto = 9f / 16f;
        private bool mostrarPrevia = true;
        private SerializedProperty imagem, opacidade, zoom, rotacao;

        private void OnEnable()
        {
            imagem = serializedObject.FindProperty("imagemForaDoCampo");
            opacidade = serializedObject.FindProperty("opacidadeImagemForaDoCampo");
            zoom = serializedObject.FindProperty("zoomFundoExterno");
            rotacao = serializedObject.FindProperty("rotacaoFundoExterno");
        }

        public override void OnInspectorGUI()
        {
            serializedObject.Update();
            SerializedProperty campo = serializedObject.GetIterator();
            bool primeiro = true;
            while (campo.NextVisible(primeiro))
            {
                primeiro = false;
                using (new EditorGUI.DisabledScope(campo.propertyPath == "m_Script"))
                    EditorGUILayout.PropertyField(campo, includeChildren: true);
                if (campo.propertyPath == "rotacaoFundoExterno") DesenharPrevia();
            }
            serializedObject.ApplyModifiedProperties();
        }

        private void DesenharPrevia()
        {
            mostrarPrevia = EditorGUILayout.Foldout(mostrarPrevia, "Prévia do fundo externo (9:16)", true);
            if (!mostrarPrevia) return;
            if (imagem.hasMultipleDifferentValues || opacidade.hasMultipleDifferentValues ||
                zoom.hasMultipleDifferentValues || rotacao.hasMultipleDifferentValues)
            {
                EditorGUILayout.HelpBox("Selecione um objeto Shorts para ver a prévia de seus ajustes.", MessageType.Info);
                return;
            }
            if (!(imagem.objectReferenceValue is Sprite sprite))
            {
                EditorGUILayout.HelpBox("Escolha um sprite em Imagem Fora Do Campo para ver a prévia.", MessageType.Info);
                return;
            }

            Rect area = GUILayoutUtility.GetAspectRect(Aspecto, GUILayout.MaxHeight(330f));
            if (Event.current.type != EventType.Repaint) return;
            float largura = Mathf.Min(area.width, area.height * Aspecto);
            float altura = largura / Aspecto;
            var quadro = new Rect(area.center.x - largura * .5f, area.center.y - altura * .5f, largura, altura);
            EditorGUI.DrawRect(quadro, new Color(.013f, .025f, .055f));
            DesenharImagem(quadro, sprite);
        }

        private void DesenharImagem(Rect quadro, Sprite sprite)
        {
            // The original texture preserves the sprite's crop even when Unity packs it in an atlas.
            Texture2D textura = SpriteUtility.GetSpriteTexture(sprite, false);
            if (textura == null) return;
            Rect recorte = sprite.rect;
            Rect uv = new Rect(recorte.x / textura.width, recorte.y / textura.height,
                recorte.width / textura.width, recorte.height / textura.height);
            Vector2 tamanho = sprite.bounds.size;
            float escala = CampoDiscos.CalcularEscalaFundoExterno(quadro.size, tamanho, zoom.floatValue, rotacao.floatValue);
            tamanho *= escala;
            Vector2 centro = quadro.size * .5f;
            Rect destino = new Rect(centro - tamanho * .5f, tamanho);

            GUI.BeginGroup(quadro);
            Matrix4x4 matriz = GUI.matrix;
            Color cor = GUI.color;
            try
            {
                // IMGUI's vertical axis points down, so invert the world rotation.
                GUIUtility.RotateAroundPivot(-rotacao.floatValue, centro);
                GUI.color = cor * new Color(1f, 1f, 1f, Mathf.Clamp01(opacidade.floatValue));
                GUI.DrawTextureWithTexCoords(destino, textura, uv, true);
            }
            finally
            {
                GUI.color = cor;
                GUI.matrix = matriz;
                GUI.EndGroup();
            }
        }
    }
}
