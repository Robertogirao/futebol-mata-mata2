using System;
using UnityEngine;

namespace FutebolDeDiscos
{
    [DisallowMultipleComponent]
    [AddComponentMenu("Futebol de Discos/Partida para Shorts")]
    public sealed class PartidaShortsDiscos : MonoBehaviour
    {
        [Header("Confronto")]
        [SerializeField] private TeamData timeA, timeB;
        [Tooltip("Opcionais. Preencha os dois para usar capitães convidados.")]
        [SerializeField] private CapitaoConvidado capitaoA, capitaoB;
        [InspectorName("Ativar especiais")]
        [Tooltip("Liga a carga, a roleta, os chutes especiais e as barras. Funciona também com os capitães normais dos times.")]
        [SerializeField] private bool ativarEspeciais;
        [Tooltip("Tempo de bola em jogo, em segundos. As pausas de gol são somadas a esse tempo.")]
        [SerializeField, Range(10f, 90f)] private float duracao = 30f;
        [SerializeField] private int semente;
        [SerializeField, Range(2, 5)] private int discosPorTime = 3;
        [InspectorName("Diâmetro dos discos")]
        [Tooltip("Altera o tamanho dos jogadores e de suas colisões. O valor padrão é 1,12.")]
        [SerializeField, Range(.6f, 1.4f)] private float diametroDiscos = 1.12f;
        [InspectorName("Limitar à própria metade")]
        [Tooltip("Quando desmarcado, a tática do time permite que jogadores atravessem o meio-campo para pressionar a bola.")]
        [SerializeField] private bool limitarPropriaMetade;

        [Header("Visual vertical")]
        [SerializeField] private TemaCompeticao tema;
        [SerializeField] private Sprite imagemNoCampo, imagemForaDoCampo;
        [SerializeField, Range(0f, 1f)] private float opacidadeImagemNoCampo = .35f, opacidadeImagemForaDoCampo = .65f;
        [InspectorName("Zoom do fundo externo")]
        [Tooltip("1 preenche o quadro. Use valores menores para afastar ou maiores para aproximar a imagem.")]
        [SerializeField, Range(.5f, 3f)] private float zoomFundoExterno = 1f;
        [InspectorName("Rotação do fundo externo (°)")]
        [Tooltip("0 deixa a imagem em pé na gravação. A rotação afeta só a imagem fora do campo.")]
        [SerializeField, Range(-180f, 180f)] private float rotacaoFundoExterno;
        [SerializeField] private Color corCampo = new Color(.025f, .21f, .17f);
        [SerializeField] private Color corLinhas = new Color(.75f, 1f, .89f);
        [SerializeField] private Color corEspecial = new Color(.99f, .78f, .30f);
        [SerializeField] private bool mostrarNomesDosJogadores = true;

        [Header("Áudio")]
        [SerializeField] private AudioClip musicaPartida;
        [SerializeField, Range(0f, 1f)] private float volumeMusica = .35f, volumeEfeitos = .7f;

        [SerializeField, HideInInspector] private Camera cameraVertical;
        [SerializeField, HideInInspector] private ProjetoFutebolDiscos regras;
        [SerializeField, HideInInspector] private UniversalUI interfacePartida;
        [SerializeField, HideInInspector] private GoalBannerUI banner;
        [SerializeField, HideInInspector] private PartidaDiscos partida;

        private const float AlturaCamera = 16.1f;
        private static readonly Quaternion RotacaoVertical = Quaternion.Euler(0f, 0f, -90f);
        private HudShortsDiscos hud;
        private int larguraVista, alturaVista;
        private bool iniciou, mostrouResultado;

        private void Start()
        {
            try
            {
                ValidarConfronto();
                AjustarCamera();
                PrepararConfiguracao();

                var objetoCampo = new GameObject("Shorts Stadium");
                objetoCampo.transform.SetParent(transform, false);
                var campo = objetoCampo.AddComponent<CampoDiscos>();
                campo.Construir(regras, espessuraMinimaArea: .065f, semilargura: 6.1f);
                campo.AjustarFundoExternoShorts(cameraVertical, zoomFundoExterno, rotacaoFundoExterno);

                TeamData.EscolherCoresParaPartida(timeA, timeB, regras.limiarCores, out Color corA, out Color corB);
                partida.Configurar(regras, campo, null, ativarEspeciais);
                var representantesA = regras.SelecionarRepresentantes(timeA);
                var representantesB = regras.SelecionarRepresentantes(timeB);
                partida.PrepararPartida(timeA, timeB, representantesA, representantesB, corA, corB);
                OrientarJogadores();
                // Reset the existing match clock and score before mounting the canvas,
                // so UniversalUI does not add the landscape player cards.
                interfacePartida.ConfigurarPartida(timeA, timeB, null, representantesA, representantesB);
                hud = new HudShortsDiscos(transform, tema, timeA, timeB, corA, corB,
                    corEspecial, interfacePartida, banner);
                partida.IniciarPartida(timeA, timeB, duracao, representantesA, representantesB, corA, corB);
                iniciou = true;
                interfacePartida.IniciarCronometro();
            }
            catch (Exception erro)
            {
                Debug.LogError("Shorts: " + erro.Message, this);
                enabled = false;
            }
        }

        private void ValidarConfronto()
        {
            if (cameraVertical == null || regras == null || interfacePartida == null || banner == null || partida == null)
                throw new InvalidOperationException("Faltam componentes da cena Shorts. Reimporte a cena do pacote.");
            if (timeA == null || timeB == null || timeA == timeB)
                throw new InvalidOperationException("Escolha duas fichas de times diferentes no Inspector de Shorts.");
            if ((capitaoA == null) != (capitaoB == null) || (capitaoA != null && capitaoA == capitaoB))
                throw new InvalidOperationException("Escolha dois capitães diferentes ou deixe os dois campos vazios.");
            if (capitaoA != null && (string.IsNullOrWhiteSpace(capitaoA.nomeCapitao) || string.IsNullOrWhiteSpace(capitaoB.nomeCapitao)))
                throw new InvalidOperationException("Preencha o nome nas duas fichas de capitães.");
        }

        private void PrepararConfiguracao()
        {
            regras.tema = tema;
            regras.discosPorTime = Mathf.Clamp(discosPorTime, 2, 5);
            regras.limitarDiscosNaMetade = limitarPropriaMetade;
            regras.semente = semente;
            regras.capitaoExtra = false;
            regras.tamanhoDisco = Mathf.Clamp(diametroDiscos, .6f, 1.4f);
            regras.tamanhoBola = .47f;
            regras.pausaAposGol = .85f;
            regras.mostrarTextoNoCampo = false;
            regras.mostrarTagsJogadores = mostrarNomesDosJogadores;
            regras.larguraTags = 2.6f;
            regras.fundoCampo = imagemNoCampo;
            regras.fundoExternoArena = imagemForaDoCampo;
            regras.opacidadeImagemCampo = opacidadeImagemNoCampo;
            regras.opacidadeFundoExterno = opacidadeImagemForaDoCampo;
            regras.corGramado = corCampo;
            regras.corLinhas = corLinhas;
            regras.corContornoCampo = corLinhas;
            regras.corBarraCapitao = corEspecial;
            regras.ConfigurarCapitaesDaPartidaAvulsa(timeA, capitaoA, timeB, capitaoB);

            duracao = Mathf.Clamp(duracao, 10f, 90f);
            interfacePartida.duracaoRealEmSegundos = duracao;
            interfacePartida.ativarGoldenGoal = false;
            interfacePartida.tempoCongeladoPosJogo = .2f;
            interfacePartida.mostrarPlacarFinal = false;
            interfacePartida.musicaPartida = musicaPartida;
            interfacePartida.volumeMusica = volumeMusica;
            interfacePartida.volumeSons = volumeEfeitos;
            if (tema != null)
            {
                if (tema.somGolDiscos != null) interfacePartida.somGol = tema.somGolDiscos;
                if (tema.somApitoInicialDiscos != null) interfacePartida.somApitoInicial = tema.somApitoInicialDiscos;
                if (tema.somApitoFinalDiscos != null) interfacePartida.somApitoFinal = tema.somApitoFinalDiscos;
                if (tema.somToqueBolaDiscos != null) interfacePartida.somToqueBola = tema.somToqueBolaDiscos;
            }
            banner.tempoDeExibicao = 1.15f;
            banner.intervaloEntreBanners = .08f;
            banner.ConfigurarCorEspecial(corEspecial);
        }

        private void AjustarCamera()
        {
            larguraVista = Mathf.Max(1, Screen.width);
            alturaVista = Mathf.Max(1, Screen.height);
            float aspecto = HudShortsDiscos.Largura / HudShortsDiscos.Altura;
            float proporcaoVista = (float)larguraVista / alturaVista;
            float w = Mathf.Min(1f, aspecto / proporcaoVista);
            float h = Mathf.Min(1f, proporcaoVista / aspecto);
            cameraVertical.rect = new Rect((1f - w) * .5f, (1f - h) * .5f, w, h);
            cameraVertical.aspect = aspecto;
            cameraVertical.orthographicSize = AlturaCamera;

            // Leave room above the goals for the scoreboard and keep equal side margins.
            float unidadesPorPixel = AlturaCamera * 2f / HudShortsDiscos.Altura;
            Vector3 desvio = RotacaoVertical * new Vector3(0f, 48f * unidadesPorPixel, 0f);
            cameraVertical.transform.SetPositionAndRotation(desvio + Vector3.back * 10f, RotacaoVertical);
        }

        private void OrientarJogadores()
        {
            foreach (DiscoAtleta atleta in partida.Atletas)
            {
                // All direct children of a disc are visual. Rotate the placement as well
                // so the caption is below the disc and the captain badge stays above it.
                foreach (Transform elemento in atleta.transform)
                {
                    elemento.localPosition = RotacaoVertical * elemento.localPosition;
                    elemento.localRotation = RotacaoVertical * elemento.localRotation;
                }
            }
        }

        private void Update()
        {
            if (!iniciou) return;
            if (larguraVista != Screen.width || alturaVista != Screen.height) AjustarCamera();
            if (mostrouResultado) return;
            partida.AtualizarEspeciaisAvulsos(ativarEspeciais);
            hud.Atualizar(partida, interfacePartida.TempoAtual);
            // UniversalUI freezes gameplay while it drains the goal banner queue.
            if (!interfacePartida.partidaEmAndamento && Time.timeScale > 0f && !banner.TemBannersPendentes)
            {
                mostrouResultado = true;
                hud.MostrarResultado(interfacePartida.GolsA, interfacePartida.GolsB);
            }
        }

        private void OnDisable()
        {
            if (iniciou && interfacePartida != null) interfacePartida.CancelarPartida();
            iniciou = false;
        }
    }
}
