using System.Collections.Generic;
using UnityEngine;

namespace FutebolDeDiscos
{
    public sealed class BolaDiscos : MonoBehaviour
    {
        public Rigidbody2D Corpo { get; private set; }
        public PartidaDiscos Partida { get; private set; }
        public DiscoAtleta UltimoToque { get; private set; }
        private TrailRenderer rastro;
        private Transform imagemBola, sombraBasquete;
        private SpriteRenderer renderBola, renderSombra;
        private Vector3 escalaImagemBola, escalaSombra;
        private bool emVooBasquete;
        private RigidbodyInterpolation2D interpolacaoAntesDoVoo;
        // O chute e o callback da bola podem chegar em qualquer ordem.
        // Um contato contínuo carrega uma vez; sair e voltar permite novo toque.
        private readonly HashSet<DiscoAtleta> contatosAtletas = new HashSet<DiscoAtleta>();
        private readonly Dictionary<DiscoAtleta, float> ultimosSonsDeToque = new Dictionary<DiscoAtleta, float>();
        public void Criar(PartidaDiscos partida, float diametro, Sprite sprite, Material material, PhysicsMaterial2D fisica)
        {
            Partida = partida;
            transform.localScale = Vector3.one;
            Corpo = gameObject.AddComponent<Rigidbody2D>();
            Corpo.gravityScale = 0f; Corpo.mass = .45f; Corpo.linearDamping = .09f;
            Corpo.constraints = RigidbodyConstraints2D.FreezeRotation;
            Corpo.interpolation = RigidbodyInterpolation2D.Interpolate;
            Corpo.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
            Corpo.sleepMode = RigidbodySleepMode2D.NeverSleep;
            var col = gameObject.AddComponent<CircleCollider2D>(); col.radius = diametro * .5f; col.sharedMaterial = fisica;
            var image = new GameObject("White Match Ball"); image.transform.SetParent(transform, false);
            float s = diametro / Mathf.Max(.0001f, Mathf.Max(sprite.bounds.size.x, sprite.bounds.size.y));
            image.transform.localScale = new Vector3(s, s, 1f);
            var sr = image.AddComponent<SpriteRenderer>(); sr.sprite = sprite; sr.sharedMaterial = material; sr.color = Color.white; sr.sortingOrder = 20;
            imagemBola = image.transform; renderBola = sr;
            escalaImagemBola = imagemBola.localScale;
            rastro = gameObject.AddComponent<TrailRenderer>(); rastro.sharedMaterial = material;
            rastro.time = .19f; rastro.startWidth = diametro * .65f; rastro.endWidth = 0f;
            rastro.startColor = new Color(.8f, 1f, 1f, .4f); rastro.endColor = new Color(.8f, 1f, 1f, 0f);
            rastro.minVertexDistance = .08f; rastro.sortingOrder = 11;
            if (Partida.ModoBasquete)
            {
                image.name = "Orange Basketball";
                sr.color = new Color(1f, .38f, .045f);
                Corpo.bodyType = RigidbodyType2D.Dynamic;
                rastro.enabled = false;
                CriarVisualBasquete(sprite, material);
            }
            Corpo.simulated = false;
        }
        public void Repor(Vector2 pos, Vector2 velocidade)
        {
            Repor(pos, velocidade, Corpo.simulated);
        }
        public void Repor(Vector2 pos, Vector2 velocidade, bool simular)
        {
            // A frozen/interpolated body can retain its old Transform pose.
            // Teleport both representations before restoring simulation, then set velocity.
            RigidbodyInterpolation2D interpolacao = emVooBasquete ? interpolacaoAntesDoVoo : Corpo.interpolation;
            emVooBasquete = false;
            Corpo.interpolation = RigidbodyInterpolation2D.None;
            Corpo.simulated = false;
            transform.position = new Vector3(pos.x, pos.y, transform.position.z);
            Corpo.position = pos;
            Corpo.simulated = simular;
            Corpo.position = pos;
            Corpo.linearVelocity = velocidade;
            Corpo.angularVelocity = 0f;
            Corpo.interpolation = interpolacao;
            if (simular) Corpo.WakeUp();
            UltimoToque = null;
            contatosAtletas.Clear();
            ultimosSonsDeToque.Clear();
            if (rastro != null) rastro.Clear();
        }
        public void RegistrarToque(DiscoAtleta atleta, bool tocarSom = true, bool registrarContato = true)
        {
            UltimoToque = atleta;
            if (registrarContato && atleta != null && Partida != null && Partida.EmAndamento && !Partida.EmReposicao &&
                contatosAtletas.Add(atleta))
            {
                if (Partida.ModoBasquete) Partida.RegistrarContatoBasquete(atleta);
                else Partida.RegistrarToqueCapitao(atleta);
            }
            if (!tocarSom || atleta == null || Partida == null || !Partida.EmAndamento || Partida.EmReposicao) return;
            UniversalUI ui = UniversalUI.Instance;
            if (ui == null) return;

            // O chute e a colisão podem chegar no mesmo passo da física.
            // O intervalo vale por atleta: outro jogador pode tocar logo em seguida.
            float agora = Time.time;
            float ultimoSom;
            if (ultimosSonsDeToque.TryGetValue(atleta, out ultimoSom) &&
                agora - ultimoSom < Mathf.Max(.02f, ui.intervaloSomToqueBola)) return;
            if (ui.TocarSomToqueBola()) ultimosSonsDeToque[atleta] = agora;
        }

        private void CriarVisualBasquete(Sprite circulo, Material material)
        {
            var sombra = new GameObject("Basketball Ground Shadow");
            sombra.transform.SetParent(transform, false);
            renderSombra = sombra.AddComponent<SpriteRenderer>();
            renderSombra.sprite = circulo; renderSombra.sharedMaterial = material;
            renderSombra.sortingOrder = 18; renderSombra.color = new Color(0f, 0f, 0f, .48f);
            sombraBasquete = sombra.transform;
            sombraBasquete.localScale = new Vector3(escalaImagemBola.x * .95f, escalaImagemBola.y * .55f, 1f);
            escalaSombra = sombraBasquete.localScale;
            // Seams use the source sprite coordinates, so any supplied circle size works.
            float raio = Mathf.Min(circulo.bounds.size.x, circulo.bounds.size.y) * .47f;
            var horizontal = new Vector3[] { new Vector3(-raio, 0f, 0f), new Vector3(raio, 0f, 0f) };
            var vertical = new Vector3[] { new Vector3(0f, -raio, 0f), new Vector3(0f, raio, 0f) };
            Costura("Basketball Horizontal Seam", horizontal, raio, material);
            Costura("Basketball Vertical Seam", vertical, raio, material);
            for (int lado = -1; lado <= 1; lado += 2)
            {
                var curva = new Vector3[17];
                for (int i = 0; i < curva.Length; i++)
                {
                    float y = Mathf.Lerp(-raio, raio, i / 16f);
                    float x = lado * raio * .58f * (1f - y * y / (raio * raio));
                    curva[i] = new Vector3(x, y, 0f);
                }
                Costura("Basketball Curved Seam", curva, raio, material);
            }
        }

        private void Costura(string nome, Vector3[] pontos, float raio, Material material)
        {
            var go = new GameObject(nome); go.transform.SetParent(imagemBola, false);
            var linha = go.AddComponent<LineRenderer>(); linha.useWorldSpace = false;
            linha.sharedMaterial = material; linha.positionCount = pontos.Length;
            linha.SetPositions(pontos); linha.startWidth = linha.endWidth = raio * .065f;
            linha.startColor = linha.endColor = new Color(.16f, .055f, .018f);
            linha.sortingOrder = 21; linha.numCapVertices = 3;
        }

        public void MoverBasquete(Vector2 posicao, float altura, float tempo, bool especial)
        {
            if (Partida == null || !Partida.ModoBasquete || Corpo == null) return;
            if (!emVooBasquete) interpolacaoAntesDoVoo = Corpo.interpolation;
            emVooBasquete = true;
            Corpo.interpolation = RigidbodyInterpolation2D.None;
            Corpo.simulated = false; Corpo.linearVelocity = Vector2.zero; Corpo.angularVelocity = 0f;
            Corpo.position = posicao;
            transform.position = new Vector3(posicao.x, posicao.y, transform.position.z);
            AtualizarVisualBasquete(altura, tempo, especial);
        }

        /// <summary>Changes height/rotation only; free-ball physics keeps its pose and velocity.</summary>
        public void AtualizarVisualBasquete(float altura, float tempo, bool especial)
        {
            if (Partida == null || !Partida.ModoBasquete || imagemBola == null) return;
            float h = Mathf.Max(0f, altura);
            imagemBola.localPosition = new Vector3(0f, h * .65f, 0f);
            imagemBola.localScale = escalaImagemBola * (1f + Mathf.Min(h, 3f) * .12f);
            imagemBola.localRotation = Quaternion.Euler(0f, 0f, -tempo * 165f);
            sombraBasquete.localScale = escalaSombra * (1f + h * .18f);
            renderSombra.color = new Color(0f, 0f, 0f, .48f / (1f + h * .7f));
            renderBola.color = especial ? new Color(1f, .65f, .08f) : new Color(1f, .38f, .045f);
        }

        public void LiberarBasquete(Vector2 posicao, Vector2 velocidade)
        {
            if (Partida == null || !Partida.ModoBasquete) return;
            Corpo.bodyType = RigidbodyType2D.Dynamic;
            GetComponent<CircleCollider2D>().enabled = true;
            Repor(posicao, velocidade, true);
            AtualizarVisualBasquete(0f, Time.time, false);
        }

        public void LimitarVelocidade(float maximo) { Corpo.linearVelocity = Vector2.ClampMagnitude(Corpo.linearVelocity, maximo); }
        private void OnCollisionEnter2D(Collision2D collision) { RegistrarContato(collision, true); }
        private void OnCollisionStay2D(Collision2D collision) { RegistrarContato(collision, false); }
        private void OnCollisionExit2D(Collision2D collision)
        {
            DiscoAtleta atleta = collision.collider.GetComponent<DiscoAtleta>();
            if (atleta != null) contatosAtletas.Remove(atleta);
        }
        private void RegistrarContato(Collision2D collision, bool tocarSom)
        {
            if (Partida == null || !Partida.EmAndamento || Partida.EmReposicao) return;
            DiscoAtleta a = collision.collider.GetComponent<DiscoAtleta>();
            if (a != null) RegistrarToque(a, tocarSom);
        }
    }
}
