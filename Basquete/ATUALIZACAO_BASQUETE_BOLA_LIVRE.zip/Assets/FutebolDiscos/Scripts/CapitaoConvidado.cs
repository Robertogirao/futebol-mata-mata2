using System;
using UnityEngine;

namespace FutebolDeDiscos
{
    // O valor zero preserva fichas e sorteios antigos, sem posição cadastrada.
    public enum PosicaoCapitao
    {
        [InspectorName("Pivô / Center")] Defesa = 0,
        [InspectorName("Armador / Guard")] Meio = 1,
        [InspectorName("Ala / Wing")] Ataque = 2
    }

    public static class PosicoesCapitao
    {
        public static bool Valida(PosicaoCapitao posicao)
        { return posicao == PosicaoCapitao.Defesa || posicao == PosicaoCapitao.Meio || posicao == PosicaoCapitao.Ataque; }

        public static string Nome(PosicaoCapitao posicao)
        { return posicao == PosicaoCapitao.Ataque ? "ATTACK" : posicao == PosicaoCapitao.Meio ? "MIDFIELD" : "DEFENSE"; }

        public static string Sigla(PosicaoCapitao posicao)
        { return posicao == PosicaoCapitao.Ataque ? "FWD" : posicao == PosicaoCapitao.Meio ? "MID" : "DEF"; }
    }

    [CreateAssetMenu(fileName = "NovoCapitao", menuName = "Basquete de Discos/Capitão convidado", order = 20)]
    public sealed class CapitaoConvidado : ScriptableObject
    {
        public string nomeCapitao = "New Captain";
        public Sprite foto;
        [Range(1, 100)]
        [Tooltip("Força individual do capitão. Não altera o overall nem os jogadores do time.")]
        public int overall = 75;
        [Tooltip("Função no basquete: pivô próximo à cesta, armador organiza a posse, ala explora as laterais. O especial só existe nas cenas de convidados.")]
        public PosicaoCapitao posicao = PosicaoCapitao.Defesa;

        // Match the existing TeamData convention: asset file names identify saved participants.
        public string Identificador { get { return name; } }

        public JogadorDados CriarJogador()
        {
            return new JogadorDados { nomeJogador = nomeCapitao.Trim(), foto512x512 = foto };
        }
    }

    [Serializable]
    public sealed class VinculoCapitaoConvidado
    {
        public TeamData time;
        public CapitaoConvidado capitao;
    }
}
