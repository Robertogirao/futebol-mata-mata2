using System;
using System.Collections.Generic;
using FutebolDeDiscos;
using UnityEngine;

namespace BasqueteDeDiscos
{
    /// <summary>Football-style physical discs and loose ball; entering the opponent paint near the ball starts a shot.</summary>
    public sealed class PartidaBasqueteDiscos
    {
        private readonly PartidaDiscos partida;
        private readonly CampoDiscos campo;
        private readonly HudFutebolDiscos hud;
        private readonly BolaDiscos bola;
        private readonly List<DiscoAtleta> atletas;
        private readonly System.Random random;
        private readonly int[] cargas = new int[2];
        private readonly Dictionary<DiscoAtleta, float> ultimosContatos = new Dictionary<DiscoAtleta, float>();
        private EstadoBasqueteDiscos estado = EstadoBasqueteDiscos.Parado;
        private bool ativo, fimPeriodo, referenciaA, especial, acertou;
        private float tempo, tempoFisica, tempoEstado, bloqueioArremesso, tempoParada;
        private Vector2 ancoraParada, origemArremesso, alvoArremesso;
        private DiscoAtleta autor, candidatoArea;
        private float tempoNaArea;
        private int pontos;
        private const float DuracaoRoleta = 1.4f;

        private ProjetoFutebolDiscos Config { get { return partida.Configuracao; } }
        public bool ArremessoPendente { get { return ativo && (estado == EstadoBasqueteDiscos.Arremesso || estado == EstadoBasqueteDiscos.Especial); } }
        // Kept for compatibility with the previous facade. Loose-ball play has no possession clock.
        public float RelogioArremesso { get { return 0f; } }
        public bool TimeComPosse { get { return bola.UltimoToque != null ? bola.UltimoToque.TimeA : referenciaA; } }
        public bool PausarRelogioPartida { get { return estado == EstadoBasqueteDiscos.Reposicao || estado == EstadoBasqueteDiscos.Especial; } }
        public EstadoBasqueteDiscos Estado { get { return estado; } }
        public float ProgressoRoleta { get { return estado == EstadoBasqueteDiscos.Especial ? Mathf.Clamp01(tempoEstado / DuracaoRoleta) : 0f; } }
        public float ChanceEspecialAtual { get; private set; }
        public bool AcertoEspecial { get { return especial && acertou; } }
        public bool ChuteEspecialEmAndamento { get { return especial && ArremessoPendente; } }
        public int CargaCapitao(bool timeA) { return Config.usarCapitaesConvidados ? cargas[timeA ? 0 : 1] : 0; }
        public bool RoletaAtiva(bool timeA) { return Config.usarCapitaesConvidados && estado == EstadoBasqueteDiscos.Especial && autor != null && autor.TimeA == timeA; }
        public bool EspecialArmado(bool timeA) { return especial && estado == EstadoBasqueteDiscos.Arremesso && autor != null && autor.TimeA == timeA; }
        public bool AcertoArmado(bool timeA) { return EspecialArmado(timeA) && acertou; }

        public PartidaBasqueteDiscos(PartidaDiscos partida, CampoDiscos campo, HudFutebolDiscos hud,
            IReadOnlyList<DiscoAtleta> atletas, BolaDiscos bola, int semente)
        {
            this.partida = partida; this.campo = campo; this.hud = hud; this.bola = bola;
            this.atletas = new List<DiscoAtleta>(atletas); random = new System.Random(semente);
            // The opening may display the court before kickoff, so never leave new discs stacked at the origin.
            foreach (DiscoAtleta atleta in this.atletas)
                atleta.Repor(PosicaoInicial(atleta.TimeA, atleta.Indice), false);
            bola.Repor(Vector2.zero, Vector2.zero, false);
        }

        private int Funcao(DiscoAtleta atleta)
        {
            return Config.usarCapitaesConvidados
                ? atleta.Capitao ? FuncoesBasqueteDiscos.DoConvidado(Config.ObterPosicaoCapitao(atleta.Equipe)) : FuncoesBasqueteDiscos.Automatico(atleta.Indice)
                : FuncoesBasqueteDiscos.DoElenco(atleta.Equipe, atleta.Jogador, atleta.Indice);
        }

        public Vector2 PosicaoInicial(bool timeA, int indice)
        {
            foreach (DiscoAtleta atleta in atletas)
                if (atleta.TimeA == timeA && atleta.Indice == indice)
                    return RegrasBasqueteDiscos.PosicaoInicial(indice, Config.TotalDiscosPorTime, timeA, Funcao(atleta));
            return RegrasBasqueteDiscos.PosicaoInicial(indice, Config.TotalDiscosPorTime, timeA, FuncoesBasqueteDiscos.Automatico(indice));
        }

        public void Iniciar(bool equipeInicialA)
        {
            Parar(); ativo = true; fimPeriodo = false; tempo = tempoFisica = 0f;
            cargas[0] = cargas[1] = 0; ultimosContatos.Clear(); ChanceEspecialAtual = .5f;
            ReporNoCentro(equipeInicialA);
        }

        public void Parar()
        {
            ativo = false; fimPeriodo = true; estado = EstadoBasqueteDiscos.Parado;
            autor = candidatoArea = null; tempoNaArea = 0f; especial = false;
            DefinirFisica(false);
            bola.AtualizarVisualBasquete(0f, tempo, false);
        }

        public void EncerrarPeriodo()
        {
            if (!ativo || fimPeriodo) return;
            fimPeriodo = true; candidatoArea = null; tempoNaArea = 0f;
            if (!ArremessoPendente) PararNoPeriodo();
        }

        public void RetomarPeriodo()
        {
            if (!ativo || !fimPeriodo || ArremessoPendente) return;
            fimPeriodo = false; ReporNoCentro(!referenciaA);
        }

        private bool PodeJogar(UniversalUI ui)
        { return ativo && partida.EmAndamento && ui != null && ui.isActiveAndEnabled && ui.partidaEmAndamento; }

        public void Avancar(float dt, UniversalUI ui)
        {
            if (!PodeJogar(ui) || !RegrasBasqueteDiscos.Finito(dt) || dt <= 0f) return;
            dt = Mathf.Min(dt, 1f); tempo += dt; tempoEstado += dt;
            if (estado == EstadoBasqueteDiscos.Reposicao)
            {
                if (!fimPeriodo && tempoEstado >= Config.duracaoReposicaoBasquete)
                {
                    DefinirFisica(true);
                    bola.LiberarBasquete(Vector2.zero, new Vector2(referenciaA ? 2.6f : -2.6f, .65f));
                    estado = EstadoBasqueteDiscos.Posse; tempoEstado = 0f;
                }
            }
            else if (estado == EstadoBasqueteDiscos.Especial)
            {
                bola.MoverBasquete(origemArremesso, .14f, tempo, true);
                if (tempoEstado >= DuracaoRoleta) IniciarVoo();
            }
            else if (estado == EstadoBasqueteDiscos.Arremesso)
            {
                float p = Mathf.Clamp01(tempoEstado / Mathf.Max(.3f, Config.duracaoArremessoBasquete));
                bola.MoverBasquete(Vector2.Lerp(origemArremesso, alvoArremesso, p), 2.2f * Mathf.Sin(p * Mathf.PI), tempo, especial);
                if (p >= 1f) ResolverArremesso(ui);
            }
            else
            {
                bola.AtualizarVisualBasquete(0f, tempo, false);
                if (estado == EstadoBasqueteDiscos.Rebote && tempoEstado >= .65f)
                { estado = EstadoBasqueteDiscos.Posse; tempoEstado = 0f; }
            }
        }

        public void AvancarFisica(float dt, UniversalUI ui)
        {
            if (!PodeJogar(ui) || fimPeriodo || !BolaLivre() || !RegrasBasqueteDiscos.Finito(dt) || dt <= 0f) return;
            tempoFisica += dt; bloqueioArremesso = Mathf.Max(0f, bloqueioArremesso - dt);
            bola.LimitarVelocidade(Config.velocidadeMaximaBola);
            AtualizarMovimentos(dt);
            VerificarArremesso(dt);
            if (!BolaLivre()) return;
            // The same small rescue impulse used in football frees a trapped ball without attaching it to a disc.
            if (Vector2.Distance(ancoraParada, bola.Corpo.position) > .45f)
            { ancoraParada = bola.Corpo.position; tempoParada = 0f; }
            else tempoParada += dt;
            if (tempoParada > 2.8f)
            {
                Vector2 direcao = new Vector2(random.Next(2) == 0 ? -1f : 1f, (float)random.NextDouble() - .5f).normalized;
                bola.Corpo.AddForce(direcao * 2.4f, ForceMode2D.Impulse); tempoParada = 0f;
            }
            Vector2 pos = bola.Corpo.position;
            if (Mathf.Abs(pos.x) > RegrasBasqueteDiscos.MeioComprimento + 1f || Mathf.Abs(pos.y) > RegrasBasqueteDiscos.MeioLargura + 1f)
            {
                bola.LiberarBasquete(Vector2.zero, new Vector2(referenciaA ? 2.6f : -2.6f, .65f));
                ancoraParada = Vector2.zero; tempoParada = 0f;
            }
        }

        private bool BolaLivre()
        { return estado == EstadoBasqueteDiscos.Posse || estado == EstadoBasqueteDiscos.Rebote; }

        public void RegistrarContato(DiscoAtleta atleta)
        {
            if (!ativo || fimPeriodo || !BolaLivre() || atleta == null || !atletas.Contains(atleta)) return;
            referenciaA = atleta.TimeA;
            if (!Config.usarCapitaesConvidados || !atleta.Capitao) return;
            float ultimo;
            if (ultimosContatos.TryGetValue(atleta, out ultimo) && tempoFisica - ultimo < .5f) return;
            ultimosContatos[atleta] = tempoFisica;
            int indice = atleta.TimeA ? 0 : 1; cargas[indice] = Mathf.Min(PartidaDiscos.ToquesParaEspecial, cargas[indice] + 1);
        }

        public void TentarToque(DiscoAtleta atleta)
        {
            UniversalUI ui = UniversalUI.Instance;
            if (!PodeJogar(ui) || fimPeriodo || !BolaLivre() || atleta == null || !atletas.Contains(atleta) || !atleta.PodeChutar(tempoFisica)) return;
            bola.RegistrarToque(atleta);
            // Keep the ball near the player while the tiny area-confirmation delay is running.
            if (ElegivelNaArea(atleta) || (Config.permitirTresPontosBasquete && ElegivelDeTres(atleta))) return;
            Vector2 alvo = RegrasBasqueteDiscos.Aro(atleta.TimeA);
            alvo.y = ((float)random.NextDouble() * 2f - 1f) * 1.15f;
            Vector2 direcao = (alvo - bola.Corpo.position).normalized;
            float habilidade = atleta.TemOverallIndividual ? .75f + atleta.OverallEfetivo / 100f * .5f : 1f;
            bola.Corpo.AddForce(direcao * Config.forcaChute * habilidade * (.82f + (float)random.NextDouble() * .18f), ForceMode2D.Impulse);
            bola.LimitarVelocidade(Config.velocidadeMaximaBola);
        }

        private bool ElegivelNaArea(DiscoAtleta atleta)
        {
            return RegrasBasqueteLivre.PodeArremessarNaArea(atleta.Corpo.position, bola.Corpo.position, atleta.TimeA,
                Config.tamanhoDisco, Config.tamanhoBola, Config.alcanceBolaArremessoBasquete);
        }

        private bool ElegivelDeTres(DiscoAtleta atleta)
        {
            return RegrasBasqueteLivre.PodeArremessarDeTres(atleta.Corpo.position, bola.Corpo.position, atleta.TimeA,
                Config.tamanhoDisco, Config.tamanhoBola, Config.alcanceBolaArremessoBasquete);
        }

        private void VerificarArremesso(float dt)
        {
            if (bloqueioArremesso > 0f) { candidatoArea = null; tempoNaArea = 0f; return; }
            DiscoAtleta maisPerto = null; float distancia = float.MaxValue;
            bool area = false;
            foreach (DiscoAtleta atleta in atletas)
            {
                bool naArea = ElegivelNaArea(atleta);
                bool deTres = !naArea && Config.permitirTresPontosBasquete && ElegivelDeTres(atleta);
                if (!naArea && !deTres) continue;
                float d = Vector2.Distance(atleta.Corpo.position, bola.Corpo.position);
                if (d < distancia) { distancia = d; maisPerto = atleta; area = naArea; }
            }
            if (maisPerto != null)
                foreach (DiscoAtleta adversario in atletas)
                    if (adversario.TimeA != maisPerto.TimeA &&
                        Vector2.Distance(adversario.Corpo.position, bola.Corpo.position) < distancia - .05f)
                    { maisPerto = null; break; }
            if (maisPerto == null) { candidatoArea = null; tempoNaArea = 0f; return; }
            if (candidatoArea != maisPerto) { candidatoArea = maisPerto; tempoNaArea = 0f; }
            tempoNaArea += dt;
            float espera = area ? Config.atrasoArremessoAreaBasquete : Config.tempoArremessoTresBasquete;
            if (tempoNaArea >= Mathf.Max(.05f, espera)) PrepararArremesso(maisPerto);
        }

        private void PrepararArremesso(DiscoAtleta jogador)
        {
            if (fimPeriodo || !BolaLivre()) return;
            autor = jogador; referenciaA = autor.TimeA;
            origemArremesso = jogador.Corpo.position;
            alvoArremesso = RegrasBasqueteDiscos.Aro(jogador.TimeA);
            pontos = RegrasBasqueteDiscos.Pontos(origemArremesso, jogador.TimeA, Config.tamanhoDisco * .5f);
            especial = Config.usarCapitaesConvidados && jogador.Capitao && cargas[jogador.TimeA ? 0 : 1] >= PartidaDiscos.ToquesParaEspecial;
            ChanceEspecialAtual = ChanceArremesso(jogador, pontos, especial);
            acertou = random.NextDouble() < ChanceEspecialAtual;
            bola.RegistrarToque(jogador, false, false);
            candidatoArea = null; tempoNaArea = 0f; DefinirFisica(false);
            if (especial)
            {
                cargas[jogador.TimeA ? 0 : 1] = 0;
                estado = EstadoBasqueteDiscos.Especial; tempoEstado = 0f;
            }
            else IniciarVoo();
        }

        private void IniciarVoo()
        { estado = EstadoBasqueteDiscos.Arremesso; tempoEstado = 0f; bola.MoverBasquete(origemArremesso, 0f, tempo, especial); }

        private float ChanceArremesso(DiscoAtleta jogador, int valor, bool especialAtivo)
        {
            int overall = Config.usarForcaDosTimes || jogador.TemOverallIndividual ? jogador.OverallEfetivo : 75;
            float defesa = 100f;
            foreach (DiscoAtleta atleta in atletas)
                if (atleta.TimeA != jogador.TimeA) defesa = Mathf.Min(defesa, Vector2.Distance(atleta.Corpo.position, jogador.Corpo.position));
            float contestacao = Mathf.Clamp01((2f - defesa) / 1.5f);
            float chance = valor == 3 ? .24f + overall * .0035f : .55f + overall * .0035f;
            chance -= contestacao * .18f;
            if (especialAtivo) chance += .18f;
            return Mathf.Clamp(chance, .12f, especialAtivo ? .97f : .94f);
        }

        private void ResolverArremesso(UniversalUI ui)
        {
            DiscoAtleta jogador = autor; bool foiEspecial = especial; int valor = pontos;
            bool cesta = acertou; especial = false; autor = null;
            // Change state before notifying UI: the same flight can never be counted twice.
            estado = EstadoBasqueteDiscos.Parado; tempoEstado = 0f;
            if (cesta)
            {
                campo.CelebrarGol(!jogador.TimeA);
                ui.RegistrarCesta(jogador.TimeA, valor, jogador, foiEspecial);
                if (!fimPeriodo) ReporNoCentro(!jogador.TimeA);
            }
            else if (!fimPeriodo)
            {
                float angulo = (float)random.NextDouble() * Mathf.PI * 2f;
                Vector2 impulso = new Vector2(jogador.TimeA ? -2f : 2f, Mathf.Sin(angulo) * 2.4f);
                Vector2 posicao = alvoArremesso + new Vector2(jogador.TimeA ? -.8f : .8f, Mathf.Sin(angulo) * .75f);
                DefinirFisica(true); bola.LiberarBasquete(posicao, impulso);
                estado = EstadoBasqueteDiscos.Rebote; bloqueioArremesso = .65f; tempoParada = 0f; ancoraParada = posicao;
            }
            if (fimPeriodo) PararNoPeriodo();
        }

        private void AtualizarMovimentos(float dt)
        {
            Vector2 posicaoBola = bola.Corpo.position;
            foreach (DiscoAtleta atleta in atletas)
            {
                int ordem = 0; float distancia = Vector2.Distance(atleta.Corpo.position, posicaoBola);
                foreach (DiscoAtleta outro in atletas)
                    if (outro != atleta && outro.TimeA == atleta.TimeA &&
                        (Vector2.Distance(outro.Corpo.position, posicaoBola) < distancia - .001f ||
                        (Mathf.Abs(Vector2.Distance(outro.Corpo.position, posicaoBola) - distancia) <= .001f && outro.Indice < atleta.Indice))) ordem++;
                float lado = atleta.TimeA ? 1f : -1f;
                Vector2 alvo;
                if (ordem == 0)
                    alvo = posicaoBola - new Vector2(lado * .22f, 0f);
                else if (ordem == 1)
                    alvo = posicaoBola + new Vector2(-lado * 1.25f, atleta.Indice % 2 == 0 ? 1.25f : -1.25f);
                else
                {
                    Vector2 inicio = PosicaoInicial(atleta.TimeA, atleta.Indice);
                    float progressao = Mathf.Clamp(lado * posicaoBola.x + 2f, 0f, 8f) * .55f;
                    alvo = inicio + new Vector2(lado * progressao, Mathf.Sin(tempoFisica * .7f + atleta.Indice) * .75f);
                }
                atleta.MoverBasqueteLivre(alvo, tempoFisica, dt);
            }
        }

        private void ReporNoCentro(bool equipeA)
        {
            referenciaA = equipeA; estado = EstadoBasqueteDiscos.Reposicao; tempoEstado = 0f;
            candidatoArea = autor = null; tempoNaArea = 0f; especial = false; bloqueioArremesso = .25f;
            foreach (DiscoAtleta atleta in atletas) atleta.Repor(PosicaoInicial(atleta.TimeA, atleta.Indice), false);
            bola.Repor(Vector2.zero, Vector2.zero, false); bola.AtualizarVisualBasquete(0f, tempo, false);
            ancoraParada = Vector2.zero; tempoParada = 0f; Physics2D.SyncTransforms();
        }

        private void PararNoPeriodo()
        {
            estado = EstadoBasqueteDiscos.Parado; especial = false; autor = candidatoArea = null; tempoNaArea = 0f;
            DefinirFisica(false); bola.AtualizarVisualBasquete(0f, tempo, false);
        }

        private void DefinirFisica(bool simular)
        {
            foreach (DiscoAtleta atleta in atletas) atleta.Congelar(!simular);
            if (!simular) { bola.Corpo.linearVelocity = Vector2.zero; bola.Corpo.angularVelocity = 0f; }
            bola.Corpo.simulated = simular;
        }
    }
}
