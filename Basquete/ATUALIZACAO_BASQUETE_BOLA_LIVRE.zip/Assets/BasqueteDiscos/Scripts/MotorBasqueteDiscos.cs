using System;
using System.Collections.Generic;
using UnityEngine;

namespace BasqueteDeDiscos
{
    public enum EstadoBasqueteDiscos { Parado, Reposicao, Posse, Passe, Arremesso, Rebote, Especial }
    public enum TipoEventoBasqueteDiscos { Drible, Passe, Roubo, Arremesso, Cesta, Rebote, Violacao, Especial }

    public sealed class AtletaBasqueteDiscos
    {
        public int Id;
        public bool TimeA, Capitao;
        public int Overall = 75;
        // 0 = guard, 1 = wing, 2 = center.
        public int Funcao;
        public Vector2 Posicao;
    }

    public sealed class ParametrosBasqueteDiscos
    {
        public float Velocidade = 3.2f, RelogioArremesso = 12f, TempoArremesso = .85f,
            TempoPasse = .28f, TempoReposicao = .8f, IntervaloDrible = .34f, RaioJogador = .5f;
        public bool EspecialAtivo;
    }

    public sealed class EventoBasqueteDiscos
    {
        public TipoEventoBasqueteDiscos Tipo;
        public int AutorId, Pontos, LanceId;
        public bool TimeA, Especial;
    }

    /// <summary>Automatic arcade basketball. No scene objects, physics goals or UI can award a basket here.</summary>
    public sealed class MotorBasqueteDiscos
    {
        private readonly List<AtletaBasqueteDiscos> atletas;
        private readonly Dictionary<int, AtletaBasqueteDiscos> porId = new Dictionary<int, AtletaBasqueteDiscos>();
        private readonly List<EventoBasqueteDiscos> eventos = new List<EventoBasqueteDiscos>();
        private readonly System.Random random;
        private readonly ParametrosBasqueteDiscos p;
        private readonly int[] cargas = new int[2];
        private readonly float[] ultimaCarga = { -10f, -10f };
        private float tempo, tempoEstado, tempoPosse, desdeRecepcao, ateDecisao, ateDrible, ateRoubo;
        private bool posseA, fimPeriodo, lanceAcerta, lanceEspecial;
        private int portador = -1, receptor = -1, interceptor = -1, autorLance = -1, pontosLance, lanceId;
        private Vector2 inicioVoo, alvoVoo, rebotePosicao;
        private const float TempoRoleta = 1.4f;

        public IReadOnlyList<AtletaBasqueteDiscos> Atletas { get { return atletas; } }
        public int PortadorId { get { return portador; } }
        public Vector2 PosicaoBola { get; private set; }
        public float AlturaBola { get; private set; }
        public EstadoBasqueteDiscos Estado { get; private set; }
        public float RelogioArremesso { get; private set; }
        public bool EmAndamento { get; private set; }
        public bool TimeComPosse { get { return posseA; } }
        public int PontosA { get; private set; }
        public int PontosB { get; private set; }
        public bool PausarRelogioPartida { get { return Estado == EstadoBasqueteDiscos.Reposicao || Estado == EstadoBasqueteDiscos.Especial; } }
        public bool ArremessoPendente { get { return Estado == EstadoBasqueteDiscos.Arremesso || Estado == EstadoBasqueteDiscos.Especial; } }
        public float ProgressoRoleta { get { return Estado == EstadoBasqueteDiscos.Especial ? Mathf.Clamp01(tempoEstado / TempoRoleta) : 0f; } }
        public float ChanceEspecialAtual { get; private set; }
        public bool AcertoEspecial { get { return lanceAcerta; } }
        public bool ChuteEspecialEmAndamento { get { return lanceEspecial && ArremessoPendente; } }

        public MotorBasqueteDiscos(IList<AtletaBasqueteDiscos> participantes, int seed, ParametrosBasqueteDiscos parametros)
        {
            if (participantes == null) throw new ArgumentNullException("participantes");
            atletas = new List<AtletaBasqueteDiscos>();
            int a = 0, b = 0, ca = 0, cb = 0;
            foreach (AtletaBasqueteDiscos atleta in participantes)
            {
                if (atleta == null || atleta.Id < 0 || porId.ContainsKey(atleta.Id))
                    throw new ArgumentException("Basketball players need unique non-negative IDs.");
                if (atleta.TimeA) { a++; if (atleta.Capitao) ca++; } else { b++; if (atleta.Capitao) cb++; }
                atleta.Overall = Mathf.Clamp(atleta.Overall, 1, 100);
                atleta.Funcao = Mathf.Clamp(atleta.Funcao, 0, 2);
                atletas.Add(atleta); porId.Add(atleta.Id, atleta);
            }
            if (a < 1 || b < 1 || a > 6 || b > 6 || ca > 1 || cb > 1)
                throw new ArgumentException("Basketball needs one to six players and at most one captain per team.");
            p = CopiarParametros(parametros ?? new ParametrosBasqueteDiscos());
            random = new System.Random(seed);
            Estado = EstadoBasqueteDiscos.Parado;
            RelogioArremesso = p.RelogioArremesso;
            PosicaoBola = Vector2.zero;
        }

        public void Iniciar(bool posseInicialA)
        {
            eventos.Clear(); PontosA = PontosB = 0; lanceId = 0; tempo = 0f;
            cargas[0] = cargas[1] = 0; ultimaCarga[0] = ultimaCarga[1] = -10f;
            fimPeriodo = false; EmAndamento = true; lanceEspecial = false;
            int ia = 0, ib = 0, na = Contar(true), nb = Contar(false);
            foreach (AtletaBasqueteDiscos atleta in atletas)
                atleta.Posicao = RegrasBasqueteDiscos.PosicaoInicial(atleta.TimeA ? ia++ : ib++, atleta.TimeA ? na : nb, atleta.TimeA, atleta.Funcao);
            Separar(); IniciarReposicao(posseInicialA);
        }

        public void Parar()
        {
            EmAndamento = false; fimPeriodo = true; Estado = EstadoBasqueteDiscos.Parado;
            portador = receptor = interceptor = -1; lanceEspecial = false; AlturaBola = 0f;
            eventos.Clear();
        }

        public void EncerrarPeriodo()
        {
            if (!EmAndamento) return;
            fimPeriodo = true;
            if (!ArremessoPendente) PararNoPeriodo();
        }

        public void RetomarPeriodo()
        {
            if (!EmAndamento || ArremessoPendente) return;
            fimPeriodo = false; IniciarReposicao(!posseA);
        }

        public int CargaCapitao(bool timeA) { return p.EspecialAtivo ? cargas[timeA ? 0 : 1] : 0; }
        public bool RoletaAtiva(bool timeA) { return p.EspecialAtivo && Estado == EstadoBasqueteDiscos.Especial && Autor.TimeA == timeA; }
        public bool EspecialArmado(bool timeA) { return p.EspecialAtivo && lanceEspecial && Estado == EstadoBasqueteDiscos.Arremesso && Autor.TimeA == timeA; }
        public bool AcertoArmado(bool timeA) { return EspecialArmado(timeA) && lanceAcerta; }
        private AtletaBasqueteDiscos Autor { get { return porId[autorLance]; } }

        public List<EventoBasqueteDiscos> ConsumirEventos()
        {
            var copia = new List<EventoBasqueteDiscos>(eventos); eventos.Clear(); return copia;
        }

        public void Avancar(float dt)
        {
            if (!EmAndamento || !RegrasBasqueteDiscos.Finito(dt) || dt <= 0f) return;
            // Bounded catch-up for a suspended editor; ordinary frames keep all their elapsed time.
            float restante = Mathf.Min(dt, 60f);
            while (restante > .000001f && EmAndamento && Estado != EstadoBasqueteDiscos.Parado)
            {
                float passo = Mathf.Min(.05f, restante); restante -= passo; Passo(passo);
            }
        }

        private void Passo(float dt)
        {
            tempo += dt; tempoEstado += dt;
            if (Estado == EstadoBasqueteDiscos.Reposicao)
            {
                if (tempoEstado >= p.TempoReposicao && !fimPeriodo) Receber(EscolherRepositor(posseA), true);
                return;
            }
            if (Estado == EstadoBasqueteDiscos.Especial)
            {
                AtletaBasqueteDiscos autor = Autor;
                PosicaoBola = autor.Posicao + new Vector2(autor.TimeA ? .62f : -.62f, .1f);
                AlturaBola = .1f + .12f * Mathf.Sin(tempoEstado * 12f);
                if (tempoEstado >= TempoRoleta) IniciarArremesso(autor, true, true);
                return;
            }
            if (Estado == EstadoBasqueteDiscos.Arremesso) { AtualizarArremesso(); return; }
            if (fimPeriodo) { PararNoPeriodo(); return; }

            MoverAtletas(dt);
            if (Estado == EstadoBasqueteDiscos.Rebote)
            {
                AlturaBola = Mathf.Max(0f, .4f * (1f - tempoEstado / .65f));
                if (tempoEstado >= .65f) ResolverRebote();
                return;
            }
            RelogioArremesso = Mathf.Max(0f, RelogioArremesso - dt);
            if (RelogioArremesso <= 0f)
            {
                Emitir(TipoEventoBasqueteDiscos.Violacao, portador, 0, false);
                IniciarReposicao(!posseA); return;
            }
            if (Estado == EstadoBasqueteDiscos.Passe) { AtualizarPasse(); return; }
            if (Estado != EstadoBasqueteDiscos.Posse || portador < 0) return;
            AtletaBasqueteDiscos dono = porId[portador];
            tempoPosse += dt; desdeRecepcao += dt; ateDrible -= dt; ateDecisao -= dt; ateRoubo -= dt;
            float drible = Mathf.Abs(Mathf.Sin(tempo * Mathf.PI / p.IntervaloDrible));
            PosicaoBola = dono.Posicao + new Vector2(dono.TimeA ? .6f : -.6f, -.14f);
            AlturaBola = .05f + drible * .18f;
            if (ateDrible <= 0f)
            {
                ateDrible += p.IntervaloDrible; Emitir(TipoEventoBasqueteDiscos.Drible, dono.Id, 0, false); Carregar(dono);
            }
            if (ateRoubo <= 0f && desdeRecepcao > .7f)
            {
                ateRoubo = .95f;
                AtletaBasqueteDiscos defensor = MaisPerto(dono.Posicao, !posseA);
                float chance = Mathf.Clamp(.07f + (defensor.Overall - dono.Overall) * .002f, .025f, .24f);
                if (Distancia(defensor.Posicao, dono.Posicao) < p.RaioJogador * 2f + .45f && random.NextDouble() < chance)
                {
                    Emitir(TipoEventoBasqueteDiscos.Roubo, defensor.Id, 0, false); Receber(defensor, true); return;
                }
            }
            if (ateDecisao <= 0f && desdeRecepcao >= .75f)
            {
                ateDecisao = .35f; Decidir(dono);
            }
        }

        private void Decidir(AtletaBasqueteDiscos dono)
        {
            float lado = dono.TimeA ? 1f : -1f;
            float distancia = Distancia(dono.Posicao, RegrasBasqueteDiscos.Aro(dono.TimeA));
            float marca = Espaco(dono);
            bool forcado = RelogioArremesso <= 2.2f || tempoPosse > 5.5f;
            bool posicionado = lado * dono.Posicao.x > 2.4f;
            if (!forcado && desdeRecepcao > .9f && desdeRecepcao < 1.8f)
            {
                AtletaBasqueteDiscos companheiro = MelhorPasse(dono);
                if (companheiro != null && (random.NextDouble() < (marca < 1.6f ? .35 : .14)))
                { IniciarPasse(dono, companheiro); return; }
            }
            if (forcado || (posicionado && distancia < 8.5f && (marca > 1.1f || desdeRecepcao > 1.8f)))
            {
                if (p.EspecialAtivo && dono.Capitao && cargas[dono.TimeA ? 0 : 1] >= 5)
                {
                    autorLance = dono.Id; lanceEspecial = true;
                    ChanceEspecialAtual = ChanceArremesso(dono, true);
                    lanceAcerta = random.NextDouble() < ChanceEspecialAtual;
                    cargas[dono.TimeA ? 0 : 1] = 0;
                    Estado = EstadoBasqueteDiscos.Especial; tempoEstado = 0f;
                    Emitir(TipoEventoBasqueteDiscos.Especial, dono.Id, 0, true);
                }
                else IniciarArremesso(dono, false, false);
            }
        }

        private void IniciarPasse(AtletaBasqueteDiscos dono, AtletaBasqueteDiscos destino)
        {
            inicioVoo = PosicaoBola; alvoVoo = destino.Posicao;
            receptor = destino.Id; interceptor = -1;
            float maisProximo = .75f;
            foreach (AtletaBasqueteDiscos defensor in atletas)
            {
                if (defensor.TimeA == dono.TimeA) continue;
                float d = DistanciaSegmento(defensor.Posicao, inicioVoo, alvoVoo);
                if (d < maisProximo && random.NextDouble() < Mathf.Clamp(.14f + defensor.Overall * .0015f, .15f, .31f))
                { maisProximo = d; interceptor = defensor.Id; }
            }
            Emitir(TipoEventoBasqueteDiscos.Passe, dono.Id, 0, false); Carregar(dono);
            portador = -1; Estado = EstadoBasqueteDiscos.Passe; tempoEstado = 0f;
        }

        private void AtualizarPasse()
        {
            float t = Mathf.Clamp01(tempoEstado / p.TempoPasse);
            alvoVoo = porId[interceptor >= 0 ? interceptor : receptor].Posicao;
            PosicaoBola = Vector2.Lerp(inicioVoo, alvoVoo, t); AlturaBola = .15f + .3f * Mathf.Sin(t * Mathf.PI);
            if (t < 1f) return;
            AtletaBasqueteDiscos destino = porId[interceptor >= 0 ? interceptor : receptor];
            if (interceptor >= 0) Emitir(TipoEventoBasqueteDiscos.Roubo, destino.Id, 0, false);
            Receber(destino, destino.TimeA != posseA);
        }

        private void IniciarArremesso(AtletaBasqueteDiscos dono, bool especial, bool resultadoPredefinido)
        {
            autorLance = dono.Id; lanceEspecial = especial; lanceId++;
            inicioVoo = dono.Posicao;
            pontosLance = RegrasBasqueteDiscos.Pontos(inicioVoo, dono.TimeA, p.RaioJogador);
            if (!resultadoPredefinido) lanceAcerta = random.NextDouble() < ChanceArremesso(dono, especial);
            alvoVoo = RegrasBasqueteDiscos.Aro(dono.TimeA);
            Estado = EstadoBasqueteDiscos.Arremesso; tempoEstado = 0f; portador = -1;
            PosicaoBola = inicioVoo; AlturaBola = .2f;
            Emitir(TipoEventoBasqueteDiscos.Arremesso, dono.Id, pontosLance, especial);
        }

        private void AtualizarArremesso()
        {
            float t = Mathf.Clamp01(tempoEstado / p.TempoArremesso);
            PosicaoBola = Vector2.Lerp(inicioVoo, alvoVoo, t);
            AlturaBola = .12f + 2.2f * Mathf.Sin(t * Mathf.PI);
            if (t < 1f) return;
            AtletaBasqueteDiscos autor = Autor;
            if (lanceAcerta)
            {
                if (autor.TimeA) PontosA += pontosLance; else PontosB += pontosLance;
                Emitir(TipoEventoBasqueteDiscos.Cesta, autor.Id, pontosLance, lanceEspecial);
                if (fimPeriodo) PararNoPeriodo(); else IniciarReposicao(!autor.TimeA);
                return;
            }
            if (fimPeriodo) { PararNoPeriodo(); return; }
            float angulo = (float)(random.NextDouble() * Math.PI * 2d);
            float afastamento = 1.05f + (float)random.NextDouble() * 1.2f;
            rebotePosicao = Limitar(alvoVoo + new Vector2(Mathf.Cos(angulo), Mathf.Sin(angulo)) * afastamento);
            PosicaoBola = rebotePosicao; AlturaBola = .4f;
            Estado = EstadoBasqueteDiscos.Rebote; tempoEstado = 0f; lanceEspecial = false;
        }

        private void ResolverRebote()
        {
            AtletaBasqueteDiscos vencedor = null; float melhor = float.MaxValue;
            foreach (AtletaBasqueteDiscos atleta in atletas)
            {
                float valor = Distancia(atleta.Posicao, rebotePosicao) - atleta.Overall * .004f - (atleta.Funcao == 2 ? .4f : 0f)
                    + (float)random.NextDouble() * .22f;
                if (valor < melhor) { melhor = valor; vencedor = atleta; }
            }
            bool ofensivo = vencedor.TimeA == posseA;
            Emitir(TipoEventoBasqueteDiscos.Rebote, vencedor.Id, 0, false);
            Receber(vencedor, !ofensivo);
            if (ofensivo) RelogioArremesso = Mathf.Min(8f, p.RelogioArremesso);
        }

        private void Receber(AtletaBasqueteDiscos atleta, bool novaPosse)
        {
            bool trocou = atleta.TimeA != posseA;
            posseA = atleta.TimeA; portador = atleta.Id; receptor = interceptor = -1;
            Estado = EstadoBasqueteDiscos.Posse; tempoEstado = 0f; desdeRecepcao = 0f;
            ateDrible = .12f; ateDecisao = .4f; ateRoubo = .9f; lanceEspecial = false;
            if (novaPosse || trocou) { RelogioArremesso = p.RelogioArremesso; tempoPosse = 0f; }
            PosicaoBola = atleta.Posicao; AlturaBola = .1f; Carregar(atleta);
        }

        private void IniciarReposicao(bool timeA)
        {
            posseA = timeA; Estado = EstadoBasqueteDiscos.Reposicao; tempoEstado = tempoPosse = 0f;
            RelogioArremesso = p.RelogioArremesso; portador = receptor = interceptor = -1; lanceEspecial = false; AlturaBola = 0f;
            AtletaBasqueteDiscos repositor = EscolherRepositor(timeA);
            // Reset a compact inbound formation after a basket/violation instead
            // of teleporting the ball directly into an attacking player's hands.
            int ia = 0, ib = 0, na = Contar(true), nb = Contar(false);
            foreach (AtletaBasqueteDiscos atleta in atletas)
                atleta.Posicao = RegrasBasqueteDiscos.PosicaoInicial(atleta.TimeA ? ia++ : ib++, atleta.TimeA ? na : nb, atleta.TimeA, atleta.Funcao);
            Separar(); PosicaoBola = repositor.Posicao + new Vector2(timeA ? -.7f : .7f, 0f);
        }

        private void PararNoPeriodo()
        { Estado = EstadoBasqueteDiscos.Parado; portador = receptor = interceptor = -1; lanceEspecial = false; AlturaBola = 0f; }

        private AtletaBasqueteDiscos EscolherRepositor(bool timeA)
        {
            AtletaBasqueteDiscos melhor = null;
            foreach (AtletaBasqueteDiscos atleta in atletas)
                if (atleta.TimeA == timeA && (melhor == null || atleta.Funcao < melhor.Funcao ||
                    (atleta.Funcao == melhor.Funcao && atleta.Capitao && !melhor.Capitao))) melhor = atleta;
            return melhor;
        }

        private void Carregar(AtletaBasqueteDiscos atleta)
        {
            if (!p.EspecialAtivo || !atleta.Capitao) return;
            int i = atleta.TimeA ? 0 : 1;
            if (tempo - ultimaCarga[i] < .3f) return;
            ultimaCarga[i] = tempo; cargas[i] = Mathf.Min(5, cargas[i] + 1);
        }

        private float ChanceArremesso(AtletaBasqueteDiscos dono, bool especial)
        {
            int valor = RegrasBasqueteDiscos.Pontos(dono.Posicao, dono.TimeA, p.RaioJogador);
            float distancia = Distancia(dono.Posicao, RegrasBasqueteDiscos.Aro(dono.TimeA));
            float contestacao = Mathf.Clamp01((2f - Espaco(dono)) / 1.5f);
            float chance = valor == 3 ? .24f + dono.Overall * .0035f : .79f + dono.Overall * .002f - distancia * .055f;
            chance -= contestacao * .18f;
            if (especial) chance += .22f;
            return Mathf.Clamp(chance, .06f, especial ? .97f : .92f);
        }

        private AtletaBasqueteDiscos MelhorPasse(AtletaBasqueteDiscos dono)
        {
            AtletaBasqueteDiscos melhor = null; float melhorValor = -100f;
            foreach (AtletaBasqueteDiscos atleta in atletas)
            {
                if (atleta.TimeA != dono.TimeA || atleta.Id == dono.Id || Distancia(atleta.Posicao, dono.Posicao) < 1.1f) continue;
                float dAro = Distancia(atleta.Posicao, RegrasBasqueteDiscos.Aro(dono.TimeA));
                float valor = Espaco(atleta) * .85f - dAro * .12f + (atleta.Capitao && p.EspecialAtivo ? .7f : 0f);
                if (valor > melhorValor) { melhorValor = valor; melhor = atleta; }
            }
            return melhor;
        }

        private float Espaco(AtletaBasqueteDiscos atleta) { return Distancia(atleta.Posicao, MaisPerto(atleta.Posicao, !atleta.TimeA).Posicao); }
        private AtletaBasqueteDiscos MaisPerto(Vector2 posicao, bool timeA)
        {
            AtletaBasqueteDiscos melhor = null; float distancia = float.MaxValue;
            foreach (AtletaBasqueteDiscos atleta in atletas)
                if (atleta.TimeA == timeA)
                {
                    float d = Distancia(atleta.Posicao, posicao);
                    if (d < distancia) { distancia = d; melhor = atleta; }
                }
            return melhor;
        }

        private void MoverAtletas(float dt)
        {
            AtletaBasqueteDiscos dono = portador >= 0 ? porId[portador] : null;
            AtletaBasqueteDiscos marcador = dono != null ? MaisPerto(dono.Posicao, !posseA) : null;
            foreach (AtletaBasqueteDiscos atleta in atletas)
            {
                Vector2 alvo;
                float lado = atleta.TimeA ? 1f : -1f;
                int ordem = OrdemNoTime(atleta);
                if (Estado == EstadoBasqueteDiscos.Rebote)
                {
                    alvo = rebotePosicao;
                }
                else if (atleta.TimeA == posseA)
                {
                    if (dono == atleta)
                    {
                        float x = atleta.Funcao == 0 ? 3.0f : atleta.Funcao == 1 ? 5.2f : 7.8f;
                        if (tempoPosse > 3.8f && Espaco(atleta) < 1.5f) x = 8f;
                        float y = atleta.Funcao == 2 ? Mathf.Sin(tempo * .8f + ordem) * 1.1f
                            : Mathf.Sin(tempo * .7f + ordem * 1.7f) * 2.5f;
                        alvo = new Vector2(lado * x, y);
                    }
                    else
                    {
                        float x = atleta.Funcao == 2 ? 7.9f : atleta.Funcao == 1 ? 4.2f : 2.7f;
                        float faixa = (ordem % 2 == 0 ? 1f : -1f) * (atleta.Funcao == 2 ? 1.6f : 3.8f);
                        alvo = new Vector2(lado * (x + Mathf.Sin(tempo * .4f + ordem) * .45f), faixa);
                    }
                }
                else
                {
                    AtletaBasqueteDiscos adversario = dono;
                    if (atleta != marcador || adversario == null) adversario = OponentePorOrdem(ordem, posseA);
                    if (adversario == null) alvo = Vector2.zero;
                    else
                    {
                        float ataque = adversario.TimeA ? 1f : -1f;
                        alvo = adversario.Posicao + new Vector2(ataque * .95f, 0f);
                    }
                }
                alvo = Limitar(alvo);
                float habilidade = .88f + atleta.Overall * .0024f;
                float velocidade = p.Velocidade * habilidade * (dono == atleta ? .9f : 1f);
                atleta.Posicao = Vector2.MoveTowards(atleta.Posicao, alvo, velocidade * dt);
            }
            Separar();
        }

        private void Separar()
        {
            float minimo = p.RaioJogador * 2f + .055f;
            for (int repeticao = 0; repeticao < 3; repeticao++)
                for (int i = 0; i < atletas.Count; i++)
                    for (int j = i + 1; j < atletas.Count; j++)
                    {
                        Vector2 delta = atletas[j].Posicao - atletas[i].Posicao;
                        float d = delta.magnitude;
                        if (d >= minimo) continue;
                        Vector2 direcao = d > .0001f ? delta / d : new Vector2((i + j) % 2 == 0 ? 1f : -1f, .45f).normalized;
                        Vector2 ajuste = direcao * ((minimo - d) * .51f);
                        atletas[i].Posicao = Limitar(atletas[i].Posicao - ajuste);
                        atletas[j].Posicao = Limitar(atletas[j].Posicao + ajuste);
                    }
        }

        private int OrdemNoTime(AtletaBasqueteDiscos atleta)
        {
            int ordem = 0; foreach (AtletaBasqueteDiscos outro in atletas)
            { if (outro.TimeA != atleta.TimeA) continue; if (outro == atleta) return ordem; ordem++; }
            return ordem;
        }
        private AtletaBasqueteDiscos OponentePorOrdem(int indice, bool timeA)
        {
            int atual = 0; AtletaBasqueteDiscos primeiro = null;
            foreach (AtletaBasqueteDiscos atleta in atletas)
                if (atleta.TimeA == timeA) { if (primeiro == null) primeiro = atleta; if (atual++ == indice) return atleta; }
            return primeiro;
        }
        private int Contar(bool timeA) { int n = 0; foreach (AtletaBasqueteDiscos a in atletas) if (a.TimeA == timeA) n++; return n; }
        private Vector2 Limitar(Vector2 posicao)
        {
            float x = RegrasBasqueteDiscos.MeioComprimento - p.RaioJogador - .08f;
            float y = RegrasBasqueteDiscos.MeioLargura - p.RaioJogador - .08f;
            return new Vector2(Mathf.Clamp(posicao.x, -x, x), Mathf.Clamp(posicao.y, -y, y));
        }
        private static float Distancia(Vector2 a, Vector2 b) { return Vector2.Distance(a, b); }
        private static float DistanciaSegmento(Vector2 ponto, Vector2 a, Vector2 b)
        {
            Vector2 delta = b - a; float comprimento = delta.sqrMagnitude;
            float t = comprimento < .0001f ? 0f : Mathf.Clamp01(Vector2.Dot(ponto - a, delta) / comprimento);
            return Distancia(ponto, a + delta * t);
        }
        private void Emitir(TipoEventoBasqueteDiscos tipo, int autorId, int pontos, bool especial)
        {
            bool equipe = autorId >= 0 && porId.ContainsKey(autorId) ? porId[autorId].TimeA : posseA;
            eventos.Add(new EventoBasqueteDiscos { Tipo = tipo, AutorId = autorId, TimeA = equipe, Pontos = pontos, LanceId = lanceId, Especial = especial });
        }
        private static ParametrosBasqueteDiscos CopiarParametros(ParametrosBasqueteDiscos origem)
        {
            return new ParametrosBasqueteDiscos {
                Velocidade = Seguro(origem.Velocidade, .5f, 12f, 3.2f),
                RelogioArremesso = Seguro(origem.RelogioArremesso, 2f, 60f, 12f),
                TempoArremesso = Seguro(origem.TempoArremesso, .2f, 3f, .85f),
                TempoPasse = Seguro(origem.TempoPasse, .1f, 2f, .28f),
                TempoReposicao = Seguro(origem.TempoReposicao, 0f, 5f, .8f),
                IntervaloDrible = Seguro(origem.IntervaloDrible, .12f, 2f, .34f),
                RaioJogador = Seguro(origem.RaioJogador, .2f, .8f, .5f), EspecialAtivo = origem.EspecialAtivo
            };
        }
        private static float Seguro(float valor, float min, float max, float padrao)
        { return RegrasBasqueteDiscos.Finito(valor) ? Mathf.Clamp(valor, min, max) : padrao; }
    }
}
