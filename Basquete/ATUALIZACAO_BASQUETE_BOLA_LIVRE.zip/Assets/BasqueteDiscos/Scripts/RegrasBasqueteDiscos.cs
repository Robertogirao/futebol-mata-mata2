using UnityEngine;

namespace BasqueteDeDiscos
{
    /// <summary>One court definition shared by scoring, movement and procedural drawing.</summary>
    public static class RegrasBasqueteDiscos
    {
        public const float MeioComprimento = 11f;
        public const float MeioLargura = 5.85f;
        public const float AroX = 9.4f;
        public const float RaioTres = 6f;
        public const float CantoTres = 4.65f; // Corner lane fits the default full-disc release footprint.
        private const float MargemLinha = .025f;

        public static Vector2 Aro(bool timeA) { return new Vector2(timeA ? AroX : -AroX, 0f); }

        public static int Pontos(Vector2 origem, bool timeA, float raioJogador = .5f)
        {
            if (!Finito(origem.x) || !Finito(origem.y)) return 2;
            float raio = Finito(raioJogador) ? Mathf.Max(0f, raioJogador) : .5f;
            // Touching the arc/corner line is a two-pointer. The release footprint
            // must be completely beyond at least one boundary of the two-point area.
            bool foraArco = Vector2.Distance(origem, Aro(timeA)) - raio > RaioTres + MargemLinha;
            bool foraCanto = Mathf.Abs(origem.y) - raio > CantoTres + MargemLinha;
            return foraArco || foraCanto ? 3 : 2;
        }

        public static Vector2 PosicaoInicial(int indice, int total, bool timeA, int funcao = 0)
        {
            int quantidade = Mathf.Max(1, total);
            int ordem = Mathf.Clamp(indice, 0, quantidade - 1);
            float faixa = quantidade <= 1 ? 0f : Mathf.Lerp(-3.7f, 3.7f, (float)ordem / (quantidade - 1));
            if (ordem == 0) faixa = 0f;
            else if (quantidade == 3) faixa = ordem == 1 ? -2.8f : 2.8f;
            float profundidade = funcao == 2 ? 5.2f : funcao == 1 ? 4.2f : 3.1f;
            if (ordem > 2) profundidade += (ordem % 2) * .7f;
            return new Vector2((timeA ? -1f : 1f) * profundidade, faixa);
        }

        public static bool Finito(float valor) { return !float.IsNaN(valor) && !float.IsInfinity(valor); }
    }
}
