using FutebolDeDiscos;

namespace BasqueteDeDiscos
{
    /// <summary>Map existing roster data to basketball roles without changing saved enum values.</summary>
    public static class FuncoesBasqueteDiscos
    {
        public const int Guard = 0, Wing = 1, Center = 2;
        public static int Automatico(int indice) { return indice <= 0 ? Guard : (indice - 1) % 3; }
        public static int DoConvidado(PosicaoCapitao posicao)
        { return posicao == PosicaoCapitao.Meio ? Guard : posicao == PosicaoCapitao.Ataque ? Wing : Center; }
        public static int DoElenco(TeamData equipe, JogadorDados jogador, int indice)
        {
            if (jogador != null)
            {
                switch (jogador.posicaoDiscos)
                {
                    case PosicaoJogadorDiscos.Defesa: return Center;
                    case PosicaoJogadorDiscos.Meio: return Guard;
                    case PosicaoJogadorDiscos.Ataque: return Wing;
                }
            }
            if (indice == 0 && equipe != null)
                return equipe.posicaoCapitaoDiscos == PosicaoCapitaoDiscos.Meio ? Guard
                    : equipe.posicaoCapitaoDiscos == PosicaoCapitaoDiscos.Ataque ? Wing : Center;
            return Automatico(indice);
        }
        public static string Nome(int funcao) { return funcao == Center ? "CENTER" : funcao == Wing ? "WING" : "GUARD"; }
        public static string Sigla(int funcao) { return funcao == Center ? "C" : funcao == Wing ? "W" : "PG"; }
    }
}
