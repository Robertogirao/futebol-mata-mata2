using UnityEngine;

namespace BasqueteDeDiscos
{
    /// <summary>Eligibility for a physical, free-ball court. Entering an area never awards points.</summary>
    public static class RegrasBasqueteLivre
    {
        public const float InicioGarrafao = 6.5f;
        public const float MeiaLarguraGarrafao = 1.95f;

        /// <summary>The player's center enters its opponent's painted lane.</summary>
        public static bool NoGarrafao(Vector2 disco, bool timeA)
        {
            if (!Finito(disco)) return false;
            float progresso = timeA ? disco.x : -disco.x;
            return progresso >= InicioGarrafao && progresso <= RegrasBasqueteDiscos.MeioComprimento &&
                Mathf.Abs(disco.y) <= MeiaLarguraGarrafao;
        }

        /// <summary>Both physical bodies fit on court, and the ball is within the player's reach.</summary>
        public static bool BolaProxima(Vector2 disco, Vector2 bola, float tamanhoDisco,
            float tamanhoBola, float alcanceExtra)
        {
            if (!PositivoFinito(tamanhoDisco) || !PositivoFinito(tamanhoBola) ||
                !RegrasBasqueteDiscos.Finito(alcanceExtra) || alcanceExtra < 0f) return false;
            float raioDisco = tamanhoDisco * .5f;
            float raioBola = tamanhoBola * .5f;
            if (!CorpoNaQuadra(disco, raioDisco) || !CorpoNaQuadra(bola, raioBola)) return false;
            return Vector2.Distance(disco, bola) <= raioDisco + raioBola + alcanceExtra;
        }

        public static bool PodeArremessarNaArea(Vector2 disco, Vector2 bola, bool timeA,
            float tamanhoDisco, float tamanhoBola, float alcanceExtra)
        {
            return NoGarrafao(disco, timeA) &&
                BolaProxima(disco, bola, tamanhoDisco, tamanhoBola, alcanceExtra);
        }

        /// <summary>Optional long-range eligibility; the controller decides whether this rule is enabled.</summary>
        public static bool PodeArremessarDeTres(Vector2 disco, Vector2 bola, bool timeA,
            float tamanhoDisco, float tamanhoBola, float alcanceExtra)
        {
            if (!BolaProxima(disco, bola, tamanhoDisco, tamanhoBola, alcanceExtra)) return false;
            float progresso = timeA ? disco.x : -disco.x;
            return progresso >= 1.5f && !NoGarrafao(disco, timeA) &&
                RegrasBasqueteDiscos.Pontos(disco, timeA, tamanhoDisco * .5f) == 3;
        }

        private static bool CorpoNaQuadra(Vector2 centro, float raio)
        {
            return Finito(centro) && raio <= RegrasBasqueteDiscos.MeioLargura &&
                Mathf.Abs(centro.x) <= RegrasBasqueteDiscos.MeioComprimento - raio &&
                Mathf.Abs(centro.y) <= RegrasBasqueteDiscos.MeioLargura - raio;
        }

        private static bool Finito(Vector2 ponto)
        { return RegrasBasqueteDiscos.Finito(ponto.x) && RegrasBasqueteDiscos.Finito(ponto.y); }

        private static bool PositivoFinito(float valor)
        { return RegrasBasqueteDiscos.Finito(valor) && valor > 0f; }
    }
}
