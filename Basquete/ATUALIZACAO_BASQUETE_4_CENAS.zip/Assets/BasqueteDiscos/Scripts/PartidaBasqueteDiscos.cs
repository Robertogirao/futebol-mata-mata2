using System.Collections.Generic;
using FutebolDeDiscos;
using UnityEngine;

namespace BasqueteDeDiscos
{
    /// <summary>Connects the automatic basketball model to existing team discs and broadcast UI.</summary>
    public sealed class PartidaBasqueteDiscos
    {
        private readonly PartidaDiscos partida;
        private readonly CampoDiscos campo;
        private readonly HudFutebolDiscos hud;
        private readonly BolaDiscos bola;
        private readonly List<AtletaBasqueteDiscos> elenco = new List<AtletaBasqueteDiscos>();
        private readonly Dictionary<int, DiscoAtleta> atores = new Dictionary<int, DiscoAtleta>();
        private readonly HashSet<int> cestasRegistradas = new HashSet<int>();
        private readonly int semente;
        private MotorBasqueteDiscos motor;
        private EstadoBasqueteDiscos ultimoEstado = EstadoBasqueteDiscos.Parado;
        private bool ultimaPosse;
        private float tempoVisual;

        public bool ArremessoPendente { get { return motor != null && motor.ArremessoPendente; } }
        public float RelogioArremesso { get { return motor != null ? motor.RelogioArremesso : 0f; } }
        public bool TimeComPosse { get { return motor != null && motor.TimeComPosse; } }
        public bool PausarRelogioPartida { get { return motor != null && motor.PausarRelogioPartida; } }
        public EstadoBasqueteDiscos Estado { get { return motor != null ? motor.Estado : EstadoBasqueteDiscos.Parado; } }
        public float ProgressoRoleta { get { return motor != null ? motor.ProgressoRoleta : 0f; } }
        public float ChanceEspecialAtual { get { return motor != null ? motor.ChanceEspecialAtual : .5f; } }
        public bool AcertoEspecial { get { return partida.EspecialHabilitado && motor != null && motor.AcertoEspecial; } }
        public bool ChuteEspecialEmAndamento { get { return motor != null && motor.ChuteEspecialEmAndamento; } }
        public int CargaCapitao(bool timeA) { return motor != null ? motor.CargaCapitao(timeA) : 0; }
        public bool RoletaAtiva(bool timeA) { return motor != null && motor.RoletaAtiva(timeA); }
        public bool EspecialArmado(bool timeA) { return motor != null && motor.EspecialArmado(timeA); }
        public bool AcertoArmado(bool timeA) { return motor != null && motor.AcertoArmado(timeA); }

        public PartidaBasqueteDiscos(PartidaDiscos partida, CampoDiscos campo, HudFutebolDiscos hud,
            IReadOnlyList<DiscoAtleta> atletas, BolaDiscos bola, int semente)
        {
            this.partida = partida; this.campo = campo; this.hud = hud;
            this.bola = bola; this.semente = semente;
            for (int i = 0; i < atletas.Count; i++)
            {
                DiscoAtleta ator = atletas[i];
                int funcao = Funcao(ator);
                var atleta = new AtletaBasqueteDiscos
                {
                    Id = i, TimeA = ator.TimeA, Capitao = ator.Capitao,
                    Overall = partida.Configuracao.usarForcaDosTimes || ator.TemOverallIndividual ? ator.OverallEfetivo : 75, Funcao = funcao,
                    Posicao = RegrasBasqueteDiscos.PosicaoInicial(ator.Indice,
                        partida.Configuracao.TotalDiscosPorTime, ator.TimeA, funcao)
                };
                elenco.Add(atleta);
                atores.Add(i, ator);
            }
            CriarMotor();
            AplicarPoses();
        }

        private int Funcao(DiscoAtleta ator)
        {
            ProjetoFutebolDiscos cfg = partida.Configuracao;
            if (cfg.usarCapitaesConvidados)
                return ator.Capitao ? FuncoesBasqueteDiscos.DoConvidado(cfg.ObterPosicaoCapitao(ator.Equipe))
                    : FuncoesBasqueteDiscos.Automatico(ator.Indice);
            return FuncoesBasqueteDiscos.DoElenco(ator.Equipe, ator.Jogador, ator.Indice);
        }

        private void CriarMotor()
        {
            ProjetoFutebolDiscos cfg = partida.Configuracao;
            // Special authorization is scene configuration, never a roster name or portrait.
            var parametros = new ParametrosBasqueteDiscos
            {
                Velocidade = cfg.velocidadeDiscos,
                RelogioArremesso = cfg.relogioArremessoBasquete,
                TempoArremesso = cfg.duracaoArremessoBasquete,
                TempoPasse = cfg.duracaoPasseBasquete,
                TempoReposicao = cfg.duracaoReposicaoBasquete,
                IntervaloDrible = cfg.intervaloDribleBasquete,
                RaioJogador = cfg.tamanhoDisco * .5f,
                EspecialAtivo = cfg.usarCapitaesConvidados
            };
            motor = new MotorBasqueteDiscos(elenco, semente, parametros);
        }

        public Vector2 PosicaoInicial(bool timeA, int indice)
        {
            foreach (AtletaBasqueteDiscos atleta in elenco)
            {
                DiscoAtleta ator = atores[atleta.Id];
                if (ator.TimeA == timeA && ator.Indice == indice)
                    return RegrasBasqueteDiscos.PosicaoInicial(indice,
                        partida.Configuracao.TotalDiscosPorTime, timeA, atleta.Funcao);
            }
            return RegrasBasqueteDiscos.PosicaoInicial(indice,
                partida.Configuracao.TotalDiscosPorTime, timeA, FuncoesBasqueteDiscos.Automatico(indice));
        }

        public void Iniciar(bool posseA)
        {
            Parar();
            cestasRegistradas.Clear();
            tempoVisual = 0f;
            CriarMotor();
            motor.Iniciar(posseA);
            AplicarPoses();
        }

        public void Parar()
        {
            if (motor == null) return;
            motor.Parar();
            // Stop/restart is synchronous: stale dribbles and scores cannot reach another match.
            motor.ConsumirEventos();
            ultimoEstado = EstadoBasqueteDiscos.Parado;
        }

        public void EncerrarPeriodo() { if (motor != null) motor.EncerrarPeriodo(); }
        public void RetomarPeriodo()
        {
            if (motor == null) return;
            motor.RetomarPeriodo();
            AplicarPoses();
        }

        public void Avancar(float dt, UniversalUI ui)
        {
            if (motor == null || !partida.EmAndamento || ui == null || !ui.partidaEmAndamento) return;
            tempoVisual += Mathf.Max(0f, dt);
            motor.Avancar(dt);
            AplicarPoses();
            List<EventoBasqueteDiscos> eventos = motor.ConsumirEventos();
            foreach (EventoBasqueteDiscos evento in eventos)
            {
                if (!partida.EmAndamento || !ui.partidaEmAndamento) break;
                DiscoAtleta autor;
                atores.TryGetValue(evento.AutorId, out autor);
                if (evento.Tipo == TipoEventoBasqueteDiscos.Drible)
                {
                    bola.RegistrarToque(autor, false, false);
                    ui.TocarSomToqueBola();
                }
                else if (evento.Tipo == TipoEventoBasqueteDiscos.Arremesso)
                    bola.RegistrarToque(autor, false, false);
                else if (evento.Tipo == TipoEventoBasqueteDiscos.Cesta && cestasRegistradas.Add(evento.LanceId))
                {
                    campo.CelebrarGol(!evento.TimeA);
                    ui.RegistrarCesta(evento.TimeA, evento.Pontos, autor, evento.Especial);
                }
                else if (evento.Tipo == TipoEventoBasqueteDiscos.Violacao && hud != null)
                    hud.MostrarEstado("SHOT CLOCK VIOLATION");
            }
            AtualizarEstado();
        }

        private void AplicarPoses()
        {
            foreach (AtletaBasqueteDiscos atleta in motor.Atletas)
            {
                DiscoAtleta ator;
                if (atores.TryGetValue(atleta.Id, out ator) && ator != null) ator.MoverBasquete(atleta.Posicao);
            }
            bola.MoverBasquete(motor.PosicaoBola, motor.AlturaBola, tempoVisual, motor.ChuteEspecialEmAndamento);
            DiscoAtleta portador;
            if (atores.TryGetValue(motor.PortadorId, out portador)) bola.RegistrarToque(portador, false, false);
        }

        private void AtualizarEstado()
        {
            if (hud == null || (ultimoEstado == motor.Estado && ultimaPosse == motor.TimeComPosse)) return;
            ultimoEstado = motor.Estado; ultimaPosse = motor.TimeComPosse;
            string equipe = "";
            foreach (DiscoAtleta ator in atores.Values)
                if (ator.TimeA == motor.TimeComPosse)
                { equipe = ator.Equipe.nomeEquipe.ToUpperInvariant(); break; }
            string estado = motor.Estado == EstadoBasqueteDiscos.Reposicao ? "INBOUND — "
                : motor.Estado == EstadoBasqueteDiscos.Arremesso ? "SHOT — "
                : motor.Estado == EstadoBasqueteDiscos.Rebote ? "REBOUND — "
                : motor.Estado == EstadoBasqueteDiscos.Especial ? "CAPTAIN SPECIAL — "
                : motor.Estado == EstadoBasqueteDiscos.Passe ? "PASS — " : "POSSESSION — ";
            if (motor.Estado != EstadoBasqueteDiscos.Parado) hud.MostrarEstado(estado + equipe);
        }
    }
}
